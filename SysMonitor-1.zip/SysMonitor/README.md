# SysMonitor

Monitor de rendimiento para Android (Kotlin + Jetpack Compose, modo oscuro, sin anuncios, **sin permiso INTERNET**).
Pensado para Samsung Galaxy A25 5G (Android 14+; `minSdk 30`).

## Compilar e instalar

Requisitos: JDK 17 o 21, Android SDK (plataforma 35 + build-tools) y conexión a Google/Maven la primera vez.

```bash
# Opción A: Android Studio (Ladybug o superior) → File > Open → carpeta SysMonitor → Run ▶

# Opción B: línea de comandos
echo "sdk.dir=/ruta/a/Android/Sdk" > local.properties
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk

adb install -r app/build/outputs/apk/debug/app-debug.apk
# o copia el APK al móvil y ábrelo (permite "instalar apps desconocidas").
```

`./gradlew assembleRelease` también genera un APK instalable (firmado con la clave debug; cámbiala si vas a publicarlo).

## Qué funciona y con qué permisos

| Función | Sin permisos especiales | Requiere |
|---|---|---|
| RAM total / usada / disponible / swap | ✅ real (`/proc/meminfo` + ActivityManager) | — |
| Almacenamiento total / libre | ✅ real (StorageStatsManager) | — |
| Batería: nivel, estado, temperatura, voltaje, salud, corriente, potencia | ✅ real (BatteryManager) | — |
| Estado térmico, frecuencia de CPU | ✅ si el sistema lo permite, si no «No disponible» | — |
| CPU de la propia app y su RAM | ✅ | — |
| Lista de apps, búsqueda, filtros, abrir ajustes de una app | ✅ | — |
| Tamaño de app / datos / caché por app, tiempo en primer plano | ❌ | **Acceso de uso** (Ajustes) |
| Archivos y carpetas grandes | ❌ | **Acceso a todos los archivos** (Ajustes) |
| **CPU total y por núcleo**, CPU y RAM por proceso/app, apps en ejecución | ❌ (Android lo bloquea desde Android 8) | **Shizuku** |
| **Consumo de batería por app** (BatteryStats) | ❌ | **Shizuku** |

### Activar Shizuku (opcional)
1. Instala Shizuku (https://shizuku.rikka.app/download/).
2. Android 11+: Ajustes → Opciones de desarrollador → *Depuración inalámbrica* → en Shizuku, «Iniciar mediante depuración inalámbrica» (hay que repetirlo tras reiniciar el móvil).
3. Abre SysMonitor → Ajustes (o la tarjeta Shizuku) → *Conceder permiso*.

## Fiabilidad de los datos
- Cada cifra muestra su origen: **Real** (sistema/Shizuku), **Calculado** (p. ej. potencia = corriente × voltaje) o **Estimación**.
- Lo que no se puede medir muestra «No disponible» (N/D) con el motivo. No hay datos simulados.
- CPU por proceso: 100 % = un núcleo completo (como `top`), calculado entre dos lecturas de `/proc`.
- RAM por proceso: RSS (incluye páginas compartidas, por lo que la suma puede superar la RAM usada).
- Batería por app: **estimación del propio Android** (BatteryStats), no una medición directa. Su formato cambia según versión y fabricante; si no se reconoce, se indica.
- La app solo mide con la pantalla visible. No cierra procesos ni modifica el sistema.

## Estructura
```
app/src/main/java/com/sysmon/monitor/
  core/      Metric (valor|No disponible), formatos, ajustes, permisos
  data/      cpu/ memory/ storage/ battery/ apps/ proc/ + Models.kt
  shizuku/   ShizukuController (conexión) y ShellUserService (lecturas de solo lectura de /proc y batterystats)
  ui/        MainViewModel, AppRoot, theme/, components/, screens/ (Rendimiento, Almacenamiento, Batería, Aplicaciones)
app/src/main/aidl/…/IShellService.aidl
```
