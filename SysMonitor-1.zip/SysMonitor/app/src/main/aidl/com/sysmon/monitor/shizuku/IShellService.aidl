package com.sysmon.monitor.shizuku;

// Interfaz del UserService que Shizuku ejecuta con el UID de shell (adb) o root.
// Solo expone operaciones de LECTURA con formato fijo. No hay "exec" genérico a propósito.
interface IShellService {
    // Código de transacción reservado por Shizuku para destruir el servicio.
    void destroy() = 16777114;

    // Instantánea compacta de /proc: líneas "T", "C" (CPU) y "P" (procesos).
    String readProcSnapshot() = 1;

    // Consumo de batería por UID según BatteryStats (dumpsys batterystats), ya filtrado.
    String readBatteryUsage() = 2;
}
