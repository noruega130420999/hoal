package com.sysmon.monitor.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sysmon.monitor.core.formatBytes
import com.sysmon.monitor.core.formatDecimal
import com.sysmon.monitor.core.formatDurationMs
import com.sysmon.monitor.core.formatKb
import com.sysmon.monitor.core.formatPercent1
import com.sysmon.monitor.data.AppRow

/** «N/D» = No disponible. Las pantallas lo explican siempre en una nota. */
const val ND = "N/D"

fun AppRow.cpuText(): String = cpuCorePercent?.let { formatPercent1(it) } ?: ND
fun AppRow.ramText(): String = ramKb?.let { formatKb(it) } ?: ND
fun AppRow.storageText(): String = storage?.let { formatBytes(it.totalBytes, decimal = true) } ?: ND
fun AppRow.batteryText(): String = batteryMah?.let { formatDecimal(it, 1) + " mAh" } ?: ND
fun AppRow.foregroundText(): String = foregroundMs?.let { formatDurationMs(it) } ?: ND

@Composable
fun StatRow(label: String, value: String, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f).padding(end = 12.dp),
        )
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
