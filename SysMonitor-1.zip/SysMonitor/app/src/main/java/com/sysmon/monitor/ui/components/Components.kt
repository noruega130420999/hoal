package com.sysmon.monitor.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.sysmon.monitor.core.Metric
import com.sysmon.monitor.core.Source

// ------------------------------------------------------------------ iconos propios (ligeros, sin material-icons-extended)

object SysIcons {
    private fun icon(name: String, path: String): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
        ).addPath(
            pathData = PathParser().parsePathString(path).toNodes(),
            fill = SolidColor(Color.Black),
        ).build()

    val Chip: ImageVector by lazy {
        icon(
            "chip",
            "M15,9H9v6h6V9zM13,13h-2v-2h2v2zM21,11V9h-2V7c0,-1.1 -0.9,-2 -2,-2h-2V3h-2v2h-2V3H9v2H7C5.9,5 5,5.9 5,7v2H3v2h2v2H3v2h2v2c0,1.1 0.9,2 2,2h2v2h2v-2h2v2h2v-2h2c1.1,0 2,-0.9 2,-2v-2h2v-2h-2v-2h2zM17,17H7V7h10V17z",
        )
    }
    val Storage: ImageVector by lazy {
        icon(
            "storage",
            "M2,20h20v-4H2v4zM4,17h2v2H4v-2zM2,4v4h20V4H2zM6,7H4V5h2v2zM2,14h20v-4H2v4zM4,11h2v2H4v-2z",
        )
    }
    val Battery: ImageVector by lazy {
        icon(
            "battery",
            "M15.67,4H14V2h-4v2H8.33C7.6,4 7,4.6 7,5.33v15.33C7,21.4 7.6,22 8.33,22h7.33c0.74,0 1.34,-0.6 1.34,-1.33V5.33C17,4.6 16.4,4 15.67,4z",
        )
    }
    val Phone: ImageVector by lazy {
        icon(
            "phone",
            "M17,1.01L7,1c-1.1,0 -2,0.9 -2,2v18c0,1.1 0.9,2 2,2h10c1.1,0 2,-0.9 2,-2V3c0,-1.1 -0.9,-1.99 -2,-1.99zM17,19H7V5h10v14z",
        )
    }
}

// ------------------------------------------------------------------ contenedores

@Composable
fun SysCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(16.dp)
    val m = if (onClick != null) modifier.clip(shape).clickable(onClick = onClick) else modifier
    Card(
        modifier = m,
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(modifier = Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onBackground,
        modifier = modifier.padding(top = 4.dp),
    )
}

@Composable
fun SmallNote(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier,
    )
}

// ------------------------------------------------------------------ origen de los datos / no disponible

@Composable
fun SourceBadge(source: Source, modifier: Modifier = Modifier) {
    val scheme = MaterialTheme.colorScheme
    val color = when (source) {
        Source.SYSTEM_API, Source.SYSTEM_FILE -> scheme.secondary
        Source.SHIZUKU -> scheme.primary
        Source.CALCULATED -> scheme.tertiary
        Source.ESTIMATE -> scheme.tertiary
    }
    Surface(
        shape = RoundedCornerShape(50),
        color = color.copy(alpha = 0.14f),
        modifier = modifier,
    ) {
        Text(
            text = source.label,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
        )
    }
}

@Composable
fun UnavailableBlock(reason: String?, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(
            text = "No disponible",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (!reason.isNullOrBlank()) {
            SmallNote(reason)
        }
    }
}

/** Muestra el valor con su origen, o «No disponible» con el motivo. */
@Composable
fun <T> MetricText(
    metric: Metric<T>?,
    format: (T) -> String,
    modifier: Modifier = Modifier,
    style: androidx.compose.ui.text.TextStyle = MaterialTheme.typography.titleMedium,
) {
    when (metric) {
        null -> Text("…", modifier = modifier, style = style, color = MaterialTheme.colorScheme.onSurfaceVariant)
        is Metric.Value -> Text(format(metric.value), modifier = modifier, style = style)
        is Metric.Unavailable -> Text(
            "No disponible",
            modifier = modifier,
            style = style,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// ------------------------------------------------------------------ filas clave/valor

@Composable
fun KeyValueRow(
    label: String,
    metric: Metric<*>?,
    text: String?,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f),
            )
            when (metric) {
                is Metric.Value<*> -> {
                    Text(text ?: "", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.width(8.dp))
                    SourceBadge(metric.source)
                }

                is Metric.Unavailable -> Text(
                    "No disponible",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                null -> Text("…", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (metric is Metric.Unavailable) SmallNote(metric.reason)
    }
}

// ------------------------------------------------------------------ barras y gráficas

@Composable
fun UsageBar(progress: Float, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.primary) {
    Box(
        modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .background(color),
        )
    }
}

/** Gráfica de línea sencilla (sin animaciones). La última muestra queda pegada al borde derecho. */
@Composable
fun LineChart(
    values: List<Float>,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary,
    minY: Float = 0f,
    maxY: Float? = 100f,
    maxPoints: Int = 60,
) {
    val grid = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
    Canvas(
        modifier
            .fillMaxWidth()
            .height(72.dp),
    ) {
        val w = size.width
        val h = size.height
        for (k in 0..2) {
            val y = h * k / 2f
            drawLine(grid, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
        }
        if (values.size < 2) return@Canvas
        val hi = maxY ?: values.max().coerceAtLeast(minY + 1f)
        val range = (hi - minY).coerceAtLeast(0.0001f)
        val step = w / (maxPoints - 1)
        val startX = w - step * (values.size - 1)
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = startX + i * step
            val y = h - ((v - minY) / range).coerceIn(0f, 1f) * h
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        val fill = Path().apply {
            addPath(path)
            lineTo(w, h)
            lineTo(startX, h)
            close()
        }
        drawPath(fill, color.copy(alpha = 0.12f))
        drawPath(path, color, style = Stroke(width = 3f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

// ------------------------------------------------------------------ chips / avisos

@Composable
fun <T> ChipRow(
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { (value, label) ->
            FilterChip(
                selected = value == selected,
                onClick = { onSelect(value) },
                label = { Text(label, maxLines = 1) },
            )
        }
    }
}

@Composable
fun InfoBanner(
    text: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
) {
    SysCard(modifier.fillMaxWidth()) {
        Text(text, style = MaterialTheme.typography.bodyMedium, overflow = TextOverflow.Clip)
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(10.dp))
            FilledTonalButton(onClick = onAction) { Text(actionLabel) }
        }
    }
}
