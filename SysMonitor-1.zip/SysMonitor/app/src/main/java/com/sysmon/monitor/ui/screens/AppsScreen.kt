package com.sysmon.monitor.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sysmon.monitor.data.AppRow
import com.sysmon.monitor.shizuku.ShizukuState
import com.sysmon.monitor.ui.MainViewModel
import com.sysmon.monitor.ui.components.ChipRow
import com.sysmon.monitor.ui.components.SmallNote
import com.sysmon.monitor.ui.components.SysCard

enum class AppSort(val label: String) {
    NAME("Nombre"), CPU("CPU"), RAM("RAM"), STORAGE("Almacenamiento"), BATTERY("Batería")
}

enum class AppFilter(val label: String) {
    ALL("Todas"), USER("Usuario"), SYSTEM("Sistema"), RUNNING("En ejecución")
}

private fun AppRow.sortKey(sort: AppSort): Double? = when (sort) {
    AppSort.NAME -> null
    AppSort.CPU -> cpuCorePercent?.toDouble()
    AppSort.RAM -> ramKb?.toDouble()
    AppSort.STORAGE -> storage?.totalBytes?.toDouble()
    AppSort.BATTERY -> batteryMah?.toDouble()
}

@Composable
fun AppsScreen(vm: MainViewModel, onAppClick: (AppRow) -> Unit) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val shizukuState by vm.shizuku.state.collectAsStateWithLifecycle()
    val perms by vm.perms.collectAsStateWithLifecycle()

    var query by rememberSaveable { mutableStateOf("") }
    var sort by rememberSaveable { mutableStateOf(AppSort.RAM) }
    var filter by rememberSaveable { mutableStateOf(AppFilter.ALL) }

    val shizukuReady = shizukuState == ShizukuState.READY

    val shown = remember(apps, query, sort, filter) {
        val q = query.trim()
        val filtered = apps.filter { a ->
            val matchesFilter = when (filter) {
                AppFilter.ALL -> true
                AppFilter.USER -> !a.isSystem
                AppFilter.SYSTEM -> a.isSystem
                AppFilter.RUNNING -> a.running == true
            }
            matchesFilter && (q.isEmpty() ||
                a.label.contains(q, ignoreCase = true) ||
                a.packageName.contains(q, ignoreCase = true))
        }
        if (sort == AppSort.NAME) {
            filtered.sortedBy { it.label.lowercase() }
        } else {
            // Los valores "No disponible" van al final, nunca se tratan como 0.
            val (withValue, without) = filtered.partition { it.sortKey(sort) != null }
            withValue.sortedByDescending { it.sortKey(sort) } + without.sortedBy { it.label.lowercase() }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Buscar por nombre o paquete") },
            )
        }
        item {
            ChipRow(
                options = AppSort.entries.map { it to it.label },
                selected = sort,
                onSelect = { sort = it },
            )
        }
        item {
            ChipRow(
                options = AppFilter.entries.map { it to it.label },
                selected = filter,
                onSelect = { filter = it },
            )
        }
        item {
            val notes = buildList {
                if (!shizukuReady) add("CPU, RAM y «En ejecución»: requieren Shizuku.")
                if (!perms.usageAccess) add("Almacenamiento y tiempo de uso: requieren «Acceso de uso».")
                if (!shizukuReady) add("Batería por app: requiere Shizuku.")
            }
            SmallNote(
                "${shown.size} aplicaciones. N/D = No disponible en este dispositivo con los permisos actuales." +
                    if (notes.isEmpty()) "" else "\n" + notes.joinToString(" "),
            )
        }
        items(shown, key = { it.packageName }) { row -> AppListItem(row, onAppClick) }
    }
}

@Composable
private fun AppListItem(row: AppRow, onClick: (AppRow) -> Unit) {
    SysCard(Modifier.fillMaxWidth(), onClick = { onClick(row) }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    row.label,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    row.packageName + if (row.isSystem) " · Sistema" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Stat("CPU", row.cpuText())
            Stat("RAM", row.ramText())
            Stat("Almac.", row.storageText())
            Stat("Batería", row.batteryText())
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodySmall)
    }
}
