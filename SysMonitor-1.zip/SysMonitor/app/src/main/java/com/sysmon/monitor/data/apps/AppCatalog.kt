package com.sysmon.monitor.data.apps

import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import com.sysmon.monitor.core.Permissions

/** Lista de aplicaciones instaladas (nombre, tipo, UID). Requiere QUERY_ALL_PACKAGES. */
class AppCatalog(private val context: Context) {

    data class Entry(val packageName: String, val label: String, val isSystem: Boolean, val uid: Int)

    @Volatile var entries: List<Entry> = emptyList()
        private set
    @Volatile var byPackage: Map<String, Entry> = emptyMap()
        private set

    @Synchronized
    fun reload() {
        val pm = context.packageManager
        val list = installed(pm).map { ai ->
            Entry(
                packageName = ai.packageName,
                label = try {
                    pm.getApplicationLabel(ai).toString()
                } catch (e: Exception) {
                    ai.packageName
                },
                isSystem = ai.flags and ApplicationInfo.FLAG_SYSTEM != 0,
                uid = ai.uid,
            )
        }
        byPackage = list.associateBy { it.packageName }
        entries = list
    }

    @Synchronized
    fun loadIfNeeded() {
        if (entries.isEmpty()) reload()
    }

    @Suppress("DEPRECATION")
    private fun installed(pm: PackageManager): List<ApplicationInfo> =
        if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
        } else {
            pm.getInstalledApplications(0)
        }
}

/** Tiempo en primer plano de las últimas 24 h. Requiere "Acceso de uso". */
class UsageStatsReader(private val context: Context) {
    fun foregroundLast24h(): Map<String, Long>? {
        if (!Permissions.hasUsageAccess(context)) return null
        return try {
            val usm = context.getSystemService(UsageStatsManager::class.java)
            val end = System.currentTimeMillis()
            val begin = end - 24L * 3_600_000L
            usm.queryAndAggregateUsageStats(begin, end).mapValues { it.value.totalTimeInForeground }
        } catch (e: Exception) {
            null
        }
    }
}
