package com.sysmon.monitor.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.sysmon.monitor.BuildConfig
import com.sysmon.monitor.data.proc.ProcSnapshot
import com.sysmon.monitor.data.proc.ProcSnapshotParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class ShizukuState {
    NOT_INSTALLED,
    NOT_RUNNING,
    UNSUPPORTED,
    NEEDS_PERMISSION,
    CONNECTING,
    READY,
}

/**
 * Integración OPCIONAL con Shizuku. Si no está instalado, no se ejecuta o el usuario no concede
 * el permiso, la app sigue funcionando con las APIs oficiales y marca como "No disponible" lo demás.
 */
class ShizukuController(private val context: Context) {

    private val _state = MutableStateFlow(ShizukuState.NOT_RUNNING)
    val state: StateFlow<ShizukuState> = _state.asStateFlow()

    private val _privilege = MutableStateFlow<String?>(null)
    /** "adb (shell)" o "root", según cómo se haya iniciado Shizuku. */
    val privilege: StateFlow<String?> = _privilege.asStateFlow()

    @Volatile private var service: IShellService? = null
    @Volatile private var binding = false
    private var started = false

    private val userServiceArgs by lazy {
        Shizuku.UserServiceArgs(ComponentName(context.packageName, ShellUserService::class.java.name))
            .daemon(false)
            .processNameSuffix("sysmon")
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
    }

    private val binderReceived = Shizuku.OnBinderReceivedListener { refreshState() }
    private val binderDead = Shizuku.OnBinderDeadListener {
        service = null
        binding = false
        refreshState()
    }
    private val permissionResult = Shizuku.OnRequestPermissionResultListener { _, _ -> refreshState() }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            binding = false
            if (binder != null && binder.pingBinder()) {
                service = IShellService.Stub.asInterface(binder)
                _state.value = ShizukuState.READY
            } else {
                refreshState()
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            binding = false
            refreshState()
        }
    }

    fun start() {
        if (started) return
        started = true
        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permissionResult)
        refreshState()
    }

    fun stop() {
        if (!started) return
        started = false
        try {
            Shizuku.removeBinderReceivedListener(binderReceived)
            Shizuku.removeBinderDeadListener(binderDead)
            Shizuku.removeRequestPermissionResultListener(permissionResult)
            if (service != null) Shizuku.unbindUserService(userServiceArgs, connection, true)
        } catch (_: Throwable) {
        }
        service = null
        binding = false
    }

    fun refreshState() {
        val installed = isInstalled()
        val alive = try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            false
        }
        if (!alive) {
            service = null
            binding = false
            _privilege.value = null
            _state.value = if (installed) ShizukuState.NOT_RUNNING else ShizukuState.NOT_INSTALLED
            return
        }
        if (Shizuku.isPreV11()) {
            _state.value = ShizukuState.UNSUPPORTED
            return
        }
        val granted = try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) {
            false
        }
        if (!granted) {
            _privilege.value = null
            _state.value = ShizukuState.NEEDS_PERMISSION
            return
        }
        val uid = try {
            Shizuku.getUid()
        } catch (e: Throwable) {
            -1
        }
        _privilege.value = when (uid) {
            0 -> "root"
            2000 -> "adb (shell)"
            else -> "uid $uid"
        }
        if (service != null) {
            _state.value = ShizukuState.READY
            return
        }
        _state.value = ShizukuState.CONNECTING
        if (!binding) {
            binding = true
            try {
                Shizuku.bindUserService(userServiceArgs, connection)
            } catch (e: Throwable) {
                binding = false
                _state.value = ShizukuState.UNSUPPORTED
            }
        }
    }

    fun requestPermission() {
        try {
            if (Shizuku.pingBinder() && !Shizuku.isPreV11()) Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Throwable) {
        }
    }

    fun isInstalled(): Boolean = try {
        context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        true
    } catch (e: Exception) {
        false
    }

    fun launchIntent() = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)

    /** Instantánea de CPU/procesos; null si Shizuku no está listo o la lectura falla. */
    suspend fun readProcSnapshot(): ProcSnapshot? = withContext<ProcSnapshot?>(Dispatchers.IO) {
        val s = service ?: return@withContext null
        try {
            ProcSnapshotParser.parse(s.readProcSnapshot())
        } catch (e: Exception) {
            null
        }
    }

    /** Texto filtrado de consumo de batería por UID; null si Shizuku no está listo. */
    suspend fun readBatteryUsageRaw(): String? = withContext<String?>(Dispatchers.IO) {
        val s = service ?: return@withContext null
        try {
            s.readBatteryUsage()
        } catch (e: Exception) {
            null
        }
    }

    companion object {
        const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
        const val DOWNLOAD_URL = "https://shizuku.rikka.app/download/"
        private const val REQUEST_CODE = 4242
    }
}
