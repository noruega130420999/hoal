package com.sysmon.monitor.data.memory

import android.app.ActivityManager
import android.content.Context
import android.os.Process
import com.sysmon.monitor.core.Metric
import com.sysmon.monitor.core.Source
import com.sysmon.monitor.data.RamInfo
import java.io.File

class MemoryMonitor(context: Context) {
    private val am = context.getSystemService(ActivityManager::class.java)

    /** RAM global del sistema. /proc/meminfo es legible por cualquier app. */
    fun read(): Metric<RamInfo> {
        return try {
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val m = readMeminfo()
            val hasAvailable = m.containsKey("MemAvailable")
            val total = m["MemTotal"] ?: (mi.totalMem / 1024L)
            val available = m["MemAvailable"] ?: (mi.availMem / 1024L)
            val cached = (m["Cached"] ?: 0L) + (m["Buffers"] ?: 0L)
            Metric.Value(
                RamInfo(
                    totalKb = total,
                    availableKb = available,
                    cachedKb = cached,
                    swapTotalKb = m["SwapTotal"] ?: 0L,
                    swapFreeKb = m["SwapFree"] ?: 0L,
                    lowMemory = mi.lowMemory,
                ),
                if (hasAvailable) Source.SYSTEM_FILE else Source.SYSTEM_API,
            )
        } catch (e: Exception) {
            Metric.Unavailable("No se pudo leer la memoria del sistema.")
        }
    }

    /** PSS de esta propia app (única que Android deja medir sin Shizuku). */
    fun selfPssKb(): Long? = try {
        am.getProcessMemoryInfo(intArrayOf(Process.myPid())).firstOrNull()?.totalPss?.toLong()
    } catch (e: Exception) {
        null
    }

    private fun readMeminfo(): Map<String, Long> {
        val out = HashMap<String, Long>()
        try {
            File("/proc/meminfo").forEachLine { line ->
                val idx = line.indexOf(':')
                if (idx > 0) {
                    val key = line.substring(0, idx)
                    val value = line.substring(idx + 1).trim().substringBefore(' ').toLongOrNull()
                    if (value != null) out[key] = value
                }
            }
        } catch (_: Exception) {
        }
        return out
    }
}
