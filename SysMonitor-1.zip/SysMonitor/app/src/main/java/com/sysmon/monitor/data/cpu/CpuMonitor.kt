package com.sysmon.monitor.data.cpu

import android.content.Context
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import com.sysmon.monitor.core.Metric
import com.sysmon.monitor.core.Source
import com.sysmon.monitor.data.CpuInfo
import com.sysmon.monitor.data.proc.ProcSnapshotParser
import com.sysmon.monitor.data.proc.cpuIdle
import com.sysmon.monitor.data.proc.cpuTotal
import java.io.File

/** Lee /proc/stat directamente. En Android 8+ SELinux lo bloquea a las apps normales: devuelve null. */
object ProcStatReader {
    fun readOrNull(): List<LongArray>? = try {
        val out = ArrayList<LongArray>()
        File("/proc/stat").bufferedReader().use { r ->
            while (true) {
                val line = r.readLine() ?: break
                if (!line.startsWith("cpu")) break
                ProcSnapshotParser.parseCpuLine(line)?.let { out.add(it) }
            }
        }
        out.takeIf { it.isNotEmpty() }
    } catch (e: Exception) {
        null
    }
}

class CpuMonitor(context: Context) {
    private val coreCount = Runtime.getRuntime().availableProcessors()
    private val powerManager = context.getSystemService(PowerManager::class.java)

    private var prev: List<LongArray>? = null
    private var prevSelfCpuMs = -1L
    private var prevSelfWallMs = -1L

    private val maxFreqs: List<Int?> by lazy {
        (0 until coreCount).map { readKhz("/sys/devices/system/cpu/cpu$it/cpufreq/cpuinfo_max_freq")?.div(1000) }
    }

    fun reset() {
        prev = null
        prevSelfCpuMs = -1L
        prevSelfWallMs = -1L
    }

    /**
     * @param shizukuLines líneas de CPU obtenidas vía Shizuku, o null si no hay Shizuku.
     */
    fun sample(shizukuLines: List<LongArray>?): CpuInfo {
        val lines = shizukuLines ?: ProcStatReader.readOrNull()
        val source = if (shizukuLines != null) Source.SHIZUKU else Source.SYSTEM_FILE

        val total: Metric<Float>
        val perCore: Metric<List<Float>>
        if (lines == null || lines.isEmpty()) {
            prev = null
            val reason = "Android bloquea /proc/stat a las apps normales. Se obtiene activando Shizuku."
            total = Metric.Unavailable(reason)
            perCore = Metric.Unavailable(reason)
        } else {
            val p = prev
            if (p == null || p.isEmpty()) {
                total = Metric.Unavailable("Midiendo…")
                perCore = Metric.Unavailable("Midiendo…")
            } else {
                val t = percentBetween(p[0], lines[0])
                total = if (t != null) Metric.Value(t, source) else Metric.Unavailable("Midiendo…")
                perCore = if (p.size == lines.size && lines.size > 1) {
                    Metric.Value((1 until lines.size).map { percentBetween(p[it], lines[it]) ?: 0f }, source)
                } else {
                    Metric.Unavailable("Midiendo…")
                }
            }
            prev = lines
        }

        val freqs = (0 until coreCount).map {
            readKhz("/sys/devices/system/cpu/cpu$it/cpufreq/scaling_cur_freq")?.div(1000)
        }
        val freqMetric: Metric<List<Int?>> = if (freqs.any { it != null }) {
            Metric.Value(freqs, Source.SYSTEM_FILE)
        } else {
            Metric.Unavailable("Android no permite leer la frecuencia de la CPU a esta app.")
        }

        val thermal: Metric<String> = try {
            Metric.Value(thermalName(powerManager.currentThermalStatus), Source.SYSTEM_API)
        } catch (e: Exception) {
            Metric.Unavailable("El sistema no informa del estado térmico.")
        }

        // CPU de esta propia app: siempre disponible.
        val cpuMs = Process.getElapsedCpuTime()
        val wallMs = SystemClock.elapsedRealtime()
        val self = if (prevSelfCpuMs >= 0 && wallMs > prevSelfWallMs) {
            ((cpuMs - prevSelfCpuMs) * 100f / (wallMs - prevSelfWallMs)).coerceAtLeast(0f)
        } else {
            null
        }
        prevSelfCpuMs = cpuMs
        prevSelfWallMs = wallMs

        return CpuInfo(total, perCore, coreCount, freqMetric, maxFreqs, thermal, self)
    }

    private fun percentBetween(a: LongArray, b: LongArray): Float? {
        val dTotal = b.cpuTotal() - a.cpuTotal()
        if (dTotal <= 0L) return null
        val dIdle = b.cpuIdle() - a.cpuIdle()
        return ((dTotal - dIdle) * 100f / dTotal).coerceIn(0f, 100f)
    }

    private fun readKhz(path: String): Int? = try {
        File(path).readText().trim().toIntOrNull()
    } catch (e: Exception) {
        null
    }

    private fun thermalName(status: Int): String = when (status) {
        PowerManager.THERMAL_STATUS_NONE -> "Normal"
        PowerManager.THERMAL_STATUS_LIGHT -> "Ligero"
        PowerManager.THERMAL_STATUS_MODERATE -> "Moderado"
        PowerManager.THERMAL_STATUS_SEVERE -> "Severo"
        PowerManager.THERMAL_STATUS_CRITICAL -> "Crítico"
        PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergencia"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "Apagado inminente"
        else -> "Desconocido"
    }
}
