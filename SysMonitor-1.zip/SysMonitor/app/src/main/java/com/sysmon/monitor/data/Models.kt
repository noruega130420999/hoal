package com.sysmon.monitor.data

import com.sysmon.monitor.core.Metric

data class CpuInfo(
    val totalPercent: Metric<Float>,
    val perCorePercent: Metric<List<Float>>,
    val coreCount: Int,
    /** Frecuencia actual por núcleo en MHz (null = núcleo apagado o ilegible). */
    val frequenciesMhz: Metric<List<Int?>>,
    val maxFrequenciesMhz: List<Int?>,
    val thermal: Metric<String>,
    /** CPU de esta misma app, en % de un núcleo (siempre medible sin permisos especiales). */
    val selfPercentOfCore: Float?,
)

data class RamInfo(
    val totalKb: Long,
    val availableKb: Long,
    val cachedKb: Long,
    val swapTotalKb: Long,
    val swapFreeKb: Long,
    val lowMemory: Boolean,
) {
    val usedKb: Long get() = (totalKb - availableKb).coerceAtLeast(0L)
    val swapUsedKb: Long get() = (swapTotalKb - swapFreeKb).coerceAtLeast(0L)
}

data class VolumeInfo(
    val name: String,
    val totalBytes: Long,
    val freeBytes: Long,
    val removable: Boolean,
) {
    val usedBytes: Long get() = (totalBytes - freeBytes).coerceAtLeast(0L)
}

/** [dataBytes] ya incluye [cacheBytes] (así lo define StorageStats). */
data class AppStorage(val appBytes: Long, val dataBytes: Long, val cacheBytes: Long) {
    val totalBytes: Long get() = appBytes + dataBytes
}

data class BatteryInfo(
    val levelPercent: Metric<Int>,
    val status: Metric<String>,
    val charging: Boolean,
    val plugged: Metric<String>,
    val temperatureC: Metric<Float>,
    val voltageMv: Metric<Int>,
    val health: Metric<String>,
    val technology: Metric<String>,
    /** Magnitud de la corriente instantánea en mA. */
    val currentMa: Metric<Float>,
    /** Potencia = corriente × voltaje (calculada). */
    val powerMw: Metric<Float>,
    val chargeCounterMah: Metric<Float>,
    val timeRemaining: Metric<String>,
    val cycleCount: Metric<Int>,
)

/** Suma de todos los procesos de un mismo paquete (o nombre de proceso nativo). */
data class ProcessGroup(
    val id: String,
    /** % de un núcleo (100 % = un núcleo completo). null = aún sin dos muestras. */
    val cpuCorePercent: Float?,
    val rssKb: Long,
    val processCount: Int,
)

/** Fila combinada para las listas. Cada campo null significa "No disponible". */
data class AppRow(
    val packageName: String,
    val label: String,
    val isSystem: Boolean,
    val installed: Boolean,
    /** true/false si se sabe (requiere Shizuku); null = No disponible. */
    val running: Boolean?,
    val cpuCorePercent: Float?,
    val ramKb: Long?,
    val storage: AppStorage?,
    val batteryMah: Float?,
    val foregroundMs: Long?,
)
