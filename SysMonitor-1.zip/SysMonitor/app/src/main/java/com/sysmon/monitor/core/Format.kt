package com.sysmon.monitor.core

import java.util.Locale

/** [decimal] = true usa base 1000 (como los Ajustes de Android para almacenamiento); false usa base 1024. */
fun formatBytes(bytes: Long, decimal: Boolean = false): String {
    val base = if (decimal) 1000.0 else 1024.0
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    if (bytes < base) return "$bytes B"
    var v = bytes.toDouble()
    var i = 0
    while (v >= base && i < units.lastIndex) {
        v /= base
        i++
    }
    val pattern = if (v >= 100) "%.0f %s" else "%.1f %s"
    return String.format(Locale.getDefault(), pattern, v, units[i])
}

fun formatKb(kb: Long): String = formatBytes(kb * 1024L)

fun formatPercent(p: Float): String = String.format(Locale.getDefault(), "%.0f%%", p)

fun formatPercent1(p: Float): String = String.format(Locale.getDefault(), "%.1f%%", p)

fun formatDecimal(v: Float, digits: Int = 1): String =
    String.format(Locale.getDefault(), "%.${digits}f", v)

fun formatDurationMs(ms: Long): String {
    val totalMin = ms / 60_000L
    if (totalMin < 1) return if (ms <= 0L) "0 min" else "< 1 min"
    val h = totalMin / 60
    val m = totalMin % 60
    return if (h > 0) "$h h $m min" else "$m min"
}
