package com.sysmon.monitor.ui

import android.app.Application
import android.content.Context
import android.os.Environment
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sysmon.monitor.core.AppSettings
import com.sysmon.monitor.core.Metric
import com.sysmon.monitor.core.Permissions
import com.sysmon.monitor.data.AppRow
import com.sysmon.monitor.data.AppStorage
import com.sysmon.monitor.data.BatteryInfo
import com.sysmon.monitor.data.CpuInfo
import com.sysmon.monitor.data.ProcessGroup
import com.sysmon.monitor.data.RamInfo
import com.sysmon.monitor.data.VolumeInfo
import com.sysmon.monitor.data.apps.AppCatalog
import com.sysmon.monitor.data.apps.UsageStatsReader
import com.sysmon.monitor.data.battery.BatteryMonitor
import com.sysmon.monitor.data.battery.BatteryUsage
import com.sysmon.monitor.data.battery.BatteryUsageParser
import com.sysmon.monitor.data.cpu.CpuMonitor
import com.sysmon.monitor.data.memory.MemoryMonitor
import com.sysmon.monitor.data.proc.ProcessSampler
import com.sysmon.monitor.data.storage.LargeFileScanner
import com.sysmon.monitor.data.storage.StorageMonitor
import com.sysmon.monitor.shizuku.ShizukuController
import com.sysmon.monitor.shizuku.ShizukuState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

data class MonitorState(
    val cpu: CpuInfo? = null,
    val ram: Metric<RamInfo>? = null,
    val battery: BatteryInfo? = null,
    val storage: Metric<VolumeInfo>? = null,
    val removable: List<VolumeInfo> = emptyList(),
    val selfPssKb: Long? = null,
    val cpuHistory: List<Float> = emptyList(),
    val ramHistory: List<Float> = emptyList(),
    val batteryTempHistory: List<Float> = emptyList(),
    val batteryPowerHistory: List<Float> = emptyList(),
    val updatedAtMs: Long = 0L,
)

data class PermissionState(val usageAccess: Boolean = false, val allFiles: Boolean = false)

data class StorageAppsState(val loading: Boolean = false, val loaded: Boolean = false)

data class BatteryUsageState(
    val loading: Boolean = false,
    val usage: BatteryUsage? = null,
    val error: String? = null,
)

sealed interface ScanState {
    data object Idle : ScanState
    data object Running : ScanState
    data class Done(val result: LargeFileScanner.Result) : ScanState
    data class Failed(val reason: String) : ScanState
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val ctx: Context = application.applicationContext

    val settings = AppSettings(ctx)
    val shizuku = ShizukuController(ctx)

    private val cpuMonitor = CpuMonitor(ctx)
    private val memoryMonitor = MemoryMonitor(ctx)
    private val batteryMonitor = BatteryMonitor(ctx)
    private val storageMonitor = StorageMonitor(ctx)
    private val catalog = AppCatalog(ctx)
    private val usageReader = UsageStatsReader(ctx)
    private val sampler = ProcessSampler()
    private val batteryParser = BatteryUsageParser(ctx.packageManager, catalog)

    private val refreshSignal = Channel<Unit>(Channel.CONFLATED)

    private val _monitor = MutableStateFlow(MonitorState())
    val monitor: StateFlow<MonitorState> = _monitor.asStateFlow()

    private val _apps = MutableStateFlow<List<AppRow>>(emptyList())
    val apps: StateFlow<List<AppRow>> = _apps.asStateFlow()

    private val _perms = MutableStateFlow(PermissionState())
    val perms: StateFlow<PermissionState> = _perms.asStateFlow()

    private val _storageState = MutableStateFlow(StorageAppsState())
    val storageState: StateFlow<StorageAppsState> = _storageState.asStateFlow()

    private val _batteryUsage = MutableStateFlow(BatteryUsageState())
    val batteryUsage: StateFlow<BatteryUsageState> = _batteryUsage.asStateFlow()

    private val _scan = MutableStateFlow<ScanState>(ScanState.Idle)
    val scan: StateFlow<ScanState> = _scan.asStateFlow()

    // Estado interno compartido entre fuentes lentas y rápidas
    @Volatile private var lastGroups: List<ProcessGroup>? = null
    @Volatile private var appStorage: Map<String, AppStorage> = emptyMap()
    @Volatile private var foreground: Map<String, Long>? = null
    @Volatile private var batteryByPackage: Map<String, Float> = emptyMap()
    @Volatile private var lastUsageRefresh = 0L
    @Volatile private var lastBatteryRefresh = 0L

    private var storageJob: Job? = null
    private var batteryJob: Job? = null
    private var scanJob: Job? = null

    private val cpuHist = ArrayDeque<Float>()
    private val ramHist = ArrayDeque<Float>()
    private val tempHist = ArrayDeque<Float>()
    private val powerHist = ArrayDeque<Float>()

    init {
        shizuku.start()
        refreshPermissions()
        viewModelScope.launch(Dispatchers.IO) {
            catalog.loadIfNeeded()
            rebuildApps()
        }
    }

    override fun onCleared() {
        shizuku.stop()
        super.onCleared()
    }

    // ---------------------------------------------------------------- bucle principal

    /** Se ejecuta mientras la pantalla es visible (repeatOnLifecycle STARTED); al ocultarse se cancela. */
    suspend fun runMonitorLoop() {
        refreshPermissions()
        shizuku.refreshState()
        cpuMonitor.reset()
        sampler.reset()
        withContext(Dispatchers.IO) {
            catalog.reload()
        }
        while (currentCoroutineContext().isActive) {
            tick()
            if (settings.autoUpdate.value) {
                withTimeoutOrNull(settings.intervalMs.value) { refreshSignal.receive() }
            } else {
                refreshSignal.receive()
            }
        }
    }

    fun refreshNow() {
        refreshSignal.trySend(Unit)
    }

    fun setAutoUpdate(enabled: Boolean) {
        settings.setAutoUpdate(enabled)
        refreshNow()
    }

    fun setIntervalMs(ms: Long) {
        settings.setIntervalMs(ms)
        refreshNow()
    }

    fun onResume() {
        lastUsageRefresh = 0L // si se acaba de conceder el acceso de uso, recarga enseguida
        refreshPermissions()
        shizuku.refreshState()
    }

    fun refreshPermissions() {
        _perms.value = PermissionState(
            usageAccess = Permissions.hasUsageAccess(ctx),
            allFiles = Permissions.hasAllFilesAccess(),
        )
    }

    private suspend fun tick() = withContext(Dispatchers.Default) {
        val snapshot = shizuku.readProcSnapshot()
        val groups = if (snapshot != null) sampler.update(snapshot) else {
            sampler.reset()
            null
        }
        lastGroups = groups

        val cpu = cpuMonitor.sample(snapshot?.cpu)
        val ram = memoryMonitor.read()
        val battery = batteryMonitor.read()
        val storage = storageMonitor.internal()
        val removable = storageMonitor.removableVolumes()
        val selfPss = if (snapshot == null) memoryMonitor.selfPssKb() else null

        (cpu.totalPercent as? Metric.Value<Float>)?.let { push(cpuHist, it.value) }
        (ram as? Metric.Value<RamInfo>)?.let {
            if (it.value.totalKb > 0) push(ramHist, it.value.usedKb * 100f / it.value.totalKb)
        }
        (battery.temperatureC as? Metric.Value<Float>)?.let { push(tempHist, it.value) }
        (battery.powerMw as? Metric.Value<Float>)?.let { push(powerHist, it.value) }

        _monitor.value = MonitorState(
            cpu = cpu,
            ram = ram,
            battery = battery,
            storage = storage,
            removable = removable,
            selfPssKb = selfPss,
            cpuHistory = cpuHist.toList(),
            ramHistory = ramHist.toList(),
            batteryTempHistory = tempHist.toList(),
            batteryPowerHistory = powerHist.toList(),
            updatedAtMs = System.currentTimeMillis(),
        )

        scheduleSlowSources()
        rebuildApps()
    }

    private fun push(q: ArrayDeque<Float>, v: Float) {
        q.addLast(v)
        while (q.size > HISTORY) q.removeFirst()
    }

    private fun scheduleSlowSources() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastUsageRefresh > 30_000L) {
            lastUsageRefresh = now
            viewModelScope.launch(Dispatchers.IO) {
                foreground = usageReader.foregroundLast24h()
                rebuildApps()
            }
        }
        if (_perms.value.usageAccess && !_storageState.value.loaded && !_storageState.value.loading) {
            refreshStorageApps()
        }
        if (shizuku.state.value == ShizukuState.READY && now - lastBatteryRefresh > 120_000L) {
            refreshBatteryUsage()
        }
    }

    // ---------------------------------------------------------------- fuentes lentas

    fun refreshStorageApps() {
        if (storageJob?.isActive == true) return
        storageJob = viewModelScope.launch(Dispatchers.IO) {
            _storageState.value = _storageState.value.copy(loading = true)
            catalog.loadIfNeeded()
            val map = storageMonitor.queryAppStorage(catalog.entries.map { it.packageName })
            if (map != null) appStorage = map
            _storageState.value = StorageAppsState(loading = false, loaded = map != null)
            rebuildApps()
        }
    }

    fun refreshBatteryUsage() {
        if (batteryJob?.isActive == true) return
        if (shizuku.state.value != ShizukuState.READY) {
            _batteryUsage.value = BatteryUsageState()
            return
        }
        lastBatteryRefresh = SystemClock.elapsedRealtime()
        batteryJob = viewModelScope.launch(Dispatchers.IO) {
            _batteryUsage.value = _batteryUsage.value.copy(loading = true, error = null)
            catalog.loadIfNeeded()
            val raw = shizuku.readBatteryUsageRaw()
            val usage = raw?.let { batteryParser.parse(it) }
            if (usage == null) {
                _batteryUsage.value = BatteryUsageState(
                    loading = false,
                    usage = null,
                    error = "El sistema no devolvió la tabla «Estimated power use» de BatteryStats " +
                        "(el formato cambia según la versión de Android y el fabricante).",
                )
            } else {
                val perPackage = HashMap<String, Float>()
                for (e in usage.apps) {
                    if (e.packages.size == 1) {
                        perPackage[e.packages[0]] = (perPackage[e.packages[0]] ?: 0f) + e.mah
                    }
                }
                batteryByPackage = perPackage
                _batteryUsage.value = BatteryUsageState(loading = false, usage = usage, error = null)
            }
            rebuildApps()
        }
    }

    fun startScan() {
        if (!Permissions.hasAllFilesAccess()) {
            _scan.value = ScanState.Failed("Falta el permiso «Acceso a todos los archivos».")
            return
        }
        scanJob?.cancel()
        _scan.value = ScanState.Running
        scanJob = viewModelScope.launch {
            try {
                @Suppress("DEPRECATION")
                val root = Environment.getExternalStorageDirectory()
                _scan.value = ScanState.Done(LargeFileScanner.scan(root))
            } catch (e: kotlinx.coroutines.CancellationException) {
                _scan.value = ScanState.Idle
                throw e
            } catch (e: Exception) {
                _scan.value = ScanState.Failed(e.message ?: "Error al escanear.")
            }
        }
    }

    fun cancelScan() {
        scanJob?.cancel()
        _scan.value = ScanState.Idle
    }

    // ---------------------------------------------------------------- combinación de fuentes

    @Synchronized
    private fun rebuildApps() {
        val groups = lastGroups
        val groupMap = groups?.associateBy { it.id }
        val entries = catalog.entries
        val rows = ArrayList<AppRow>(entries.size + 64)
        val used = HashSet<String>()
        val storageMap = appStorage
        val batteryMap = batteryByPackage
        val fg = foreground

        for (e in entries) {
            val g = groupMap?.get(e.packageName)
            if (g != null) used.add(e.packageName)
            rows.add(
                AppRow(
                    packageName = e.packageName,
                    label = e.label,
                    isSystem = e.isSystem,
                    installed = true,
                    running = if (groupMap != null) g != null else null,
                    cpuCorePercent = g?.cpuCorePercent,
                    ramKb = g?.rssKb,
                    storage = storageMap[e.packageName],
                    batteryMah = batteryMap[e.packageName],
                    foregroundMs = fg?.get(e.packageName),
                ),
            )
        }
        groups?.forEach { g ->
            if (g.id !in used) {
                rows.add(
                    AppRow(
                        packageName = g.id,
                        label = g.id.substringAfterLast('/'),
                        isSystem = true,
                        installed = false,
                        running = true,
                        cpuCorePercent = g.cpuCorePercent,
                        ramKb = g.rssKb,
                        storage = null,
                        batteryMah = null,
                        foregroundMs = null,
                    ),
                )
            }
        }
        _apps.value = rows
    }

    private companion object {
        const val HISTORY = 60
    }
}
