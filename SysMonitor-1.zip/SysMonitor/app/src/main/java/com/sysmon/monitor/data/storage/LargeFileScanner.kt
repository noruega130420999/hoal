package com.sysmon.monitor.data.storage

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.nio.file.FileVisitResult
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.SimpleFileVisitor
import java.nio.file.attribute.BasicFileAttributes
import java.util.PriorityQueue

/**
 * Recorre el almacenamiento compartido y devuelve los archivos y carpetas más grandes.
 * Requiere "Acceso a todos los archivos". Android bloquea Android/data y Android/obb incluso con ese permiso.
 * Solo lee metadatos (tamaños); no abre, modifica ni borra nada.
 */
object LargeFileScanner {

    data class BigFile(val path: String, val bytes: Long)
    data class FolderSize(val path: String, val bytes: Long)
    data class Result(
        val files: List<BigFile>,
        val folders: List<FolderSize>,
        val subfolders: List<FolderSize>,
        val fileCount: Long,
        val millis: Long,
    )

    suspend fun scan(root: File, topFiles: Int = 40, topFolders: Int = 20): Result =
        withContext(Dispatchers.IO) {
            val ctx = currentCoroutineContext()
            val started = System.currentTimeMillis()
            val rootStr = root.path
            val heap = PriorityQueue<BigFile>(Comparator.comparingLong<BigFile> { it.bytes })
            val level1 = ArrayList<FolderSize>()
            val level2 = ArrayList<FolderSize>()
            val stack = ArrayList<LongArray>()
            var count = 0L

            val visitor = object : SimpleFileVisitor<Path>() {
                override fun preVisitDirectory(dir: Path, attrs: BasicFileAttributes): FileVisitResult {
                    if (!ctx.isActive) return FileVisitResult.TERMINATE
                    stack.add(longArrayOf(0L))
                    return FileVisitResult.CONTINUE
                }

                override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                    if (!ctx.isActive) return FileVisitResult.TERMINATE
                    if (attrs.isRegularFile && stack.isNotEmpty()) {
                        val size = attrs.size()
                        count++
                        stack[stack.lastIndex][0] += size
                        if (heap.size < topFiles) {
                            heap.add(BigFile(file.toString(), size))
                        } else if (size > heap.peek().bytes) {
                            heap.poll()
                            heap.add(BigFile(file.toString(), size))
                        }
                    }
                    return FileVisitResult.CONTINUE
                }

                override fun visitFileFailed(file: Path, exc: IOException): FileVisitResult =
                    FileVisitResult.CONTINUE

                override fun postVisitDirectory(dir: Path, exc: IOException?): FileVisitResult {
                    if (stack.isEmpty()) return FileVisitResult.CONTINUE
                    val size = stack.removeAt(stack.lastIndex)[0]
                    val depth = stack.size // la raíz tiene profundidad 0
                    if (stack.isNotEmpty()) stack[stack.lastIndex][0] += size
                    val rel = dir.toString().removePrefix(rootStr).ifEmpty { "/" }
                    when (depth) {
                        1 -> level1.add(FolderSize(rel, size))
                        2 -> level2.add(FolderSize(rel, size))
                    }
                    return FileVisitResult.CONTINUE
                }
            }

            Files.walkFileTree(root.toPath(), emptySet(), Int.MAX_VALUE, visitor)

            Result(
                files = heap.sortedByDescending { it.bytes }.map { it.copy(path = it.path.removePrefix(rootStr)) },
                folders = level1.sortedByDescending { it.bytes }.take(topFolders),
                subfolders = level2.sortedByDescending { it.bytes }.take(topFolders),
                fileCount = count,
                millis = System.currentTimeMillis() - started,
            )
        }
}
