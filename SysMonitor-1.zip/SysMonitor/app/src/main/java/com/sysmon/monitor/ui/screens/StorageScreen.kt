package com.sysmon.monitor.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sysmon.monitor.core.Metric
import com.sysmon.monitor.core.Permissions
import com.sysmon.monitor.core.formatBytes
import com.sysmon.monitor.core.launchSafely
import com.sysmon.monitor.core.sourceOrNull
import com.sysmon.monitor.data.AppRow
import com.sysmon.monitor.data.VolumeInfo
import com.sysmon.monitor.data.storage.LargeFileScanner
import com.sysmon.monitor.ui.MainViewModel
import com.sysmon.monitor.ui.ScanState
import com.sysmon.monitor.ui.components.ChipRow
import com.sysmon.monitor.ui.components.InfoBanner
import com.sysmon.monitor.ui.components.SectionTitle
import com.sysmon.monitor.ui.components.SmallNote
import com.sysmon.monitor.ui.components.SourceBadge
import com.sysmon.monitor.ui.components.SysCard
import com.sysmon.monitor.ui.components.UnavailableBlock
import com.sysmon.monitor.ui.components.UsageBar

private enum class StorageSort(val label: String) {
    TOTAL("Total"), APP("App"), DATA("Datos"), CACHE("Caché")
}

@Composable
fun StorageScreen(vm: MainViewModel, onAppClick: (AppRow) -> Unit) {
    val mon by vm.monitor.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()
    val perms by vm.perms.collectAsStateWithLifecycle()
    val st by vm.storageState.collectAsStateWithLifecycle()
    val scan by vm.scan.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    var sort by rememberSaveable { mutableStateOf(StorageSort.TOTAL) }

    val rows = remember(apps, sort) {
        apps.filter { it.storage != null }
            .sortedByDescending {
                val s = it.storage!!
                when (sort) {
                    StorageSort.TOTAL -> s.totalBytes
                    StorageSort.APP -> s.appBytes
                    StorageSort.DATA -> s.dataBytes
                    StorageSort.CACHE -> s.cacheBytes
                }
            }
            .take(50)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { VolumeCard(mon.storage) }
        items(mon.removable.size) { VolumeCard(Metric.Value(mon.removable[it], com.sysmon.monitor.core.Source.SYSTEM_API)) }

        item { SectionTitle("Aplicaciones que más ocupan") }

        if (!perms.usageAccess) {
            item {
                InfoBanner(
                    "Para ver el tamaño de cada app, sus datos y su caché, Android exige el permiso «Acceso de uso». " +
                        "Actívalo para SysMonitor en la pantalla que se abre.",
                    actionLabel = "Conceder acceso de uso",
                    onAction = {
                        ctx.launchSafely(Permissions.usageAccessIntent(ctx), Permissions.usageAccessFallbackIntent())
                    },
                )
            }
        } else {
            item {
                ChipRow(
                    options = StorageSort.entries.map { it to "Por ${it.label.lowercase()}" },
                    selected = sort,
                    onSelect = { sort = it },
                )
            }
            if (st.loading && rows.isEmpty()) item { SmallNote("Calculando tamaños…") }
            if (!st.loading && rows.isEmpty()) {
                item { UnavailableBlock("Android no devolvió tamaños de aplicaciones.") }
            }
            items(rows, key = { it.packageName }) { row -> StorageRow(row, onAppClick) }
            item {
                SmallNote(
                    "App = código instalado. Datos = datos de la app (incluye la caché). Caché = parte de los datos que puede borrarse. " +
                        "Android no permite ver los tamaños de otros perfiles/usuarios.",
                )
            }
        }

        item { SectionTitle("Archivos grandes y carpetas") }
        item { ScanSection(scan, perms.allFiles, vm) }
    }
}

@Composable
private fun VolumeCard(v: Metric<VolumeInfo>?) {
    SysCard(Modifier.fillMaxWidth()) {
        when (v) {
            null -> SmallNote("Midiendo…")
            is Metric.Unavailable -> UnavailableBlock(v.reason)
            is Metric.Value -> {
                val vol = v.value
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(vol.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    SourceBadge(v.source)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "${formatBytes(vol.usedBytes, true)} usados de ${formatBytes(vol.totalBytes, true)}",
                    style = MaterialTheme.typography.titleLarge,
                )
                Spacer(Modifier.height(8.dp))
                if (vol.totalBytes > 0) {
                    UsageBar(vol.usedBytes.toFloat() / vol.totalBytes, color = MaterialTheme.colorScheme.tertiary)
                }
                Spacer(Modifier.height(8.dp))
                StatRow("Libre", formatBytes(vol.freeBytes, true))
                StatRow("Ocupado", formatBytes(vol.usedBytes, true))
                StatRow("Total", formatBytes(vol.totalBytes, true))
            }
        }
    }
}

@Composable
private fun StorageRow(row: AppRow, onClick: (AppRow) -> Unit) {
    val s = row.storage ?: return
    SysCard(Modifier.fillMaxWidth(), onClick = { onClick(row) }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                row.label,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Text(formatBytes(s.totalBytes, true), style = MaterialTheme.typography.titleSmall)
        }
        SmallNote(
            "App ${formatBytes(s.appBytes, true)} · Datos ${formatBytes(s.dataBytes, true)} · Caché ${formatBytes(s.cacheBytes, true)}",
        )
    }
}

@Composable
private fun ScanSection(scan: ScanState, allFiles: Boolean, vm: MainViewModel) {
    val ctx = LocalContext.current
    if (!allFiles) {
        InfoBanner(
            "Para buscar archivos y carpetas grandes hace falta «Acceso a todos los archivos». " +
                "Solo se leen los tamaños: la app no abre, modifica ni borra nada.",
            actionLabel = "Conceder acceso a archivos",
            onAction = {
                ctx.launchSafely(Permissions.allFilesIntent(ctx), Permissions.allFilesFallbackIntent())
            },
        )
        return
    }
    when (scan) {
        ScanState.Idle -> InfoBanner(
            "Escanea el almacenamiento compartido (Descargas, DCIM, WhatsApp, etc.).",
            actionLabel = "Buscar archivos grandes",
            onAction = { vm.startScan() },
        )

        ScanState.Running -> SysCard(Modifier.fillMaxWidth()) {
            Text("Escaneando…", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            UsageBar(0.0f)
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { vm.cancelScan() }) { Text("Cancelar") }
        }

        is ScanState.Failed -> InfoBanner(scan.reason, actionLabel = "Reintentar", onAction = { vm.startScan() })

        is ScanState.Done -> ScanResults(scan.result, onRescan = { vm.startScan() })
    }
}

@Composable
private fun ScanResults(r: LargeFileScanner.Result, onRescan: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    SysCard(Modifier.fillMaxWidth()) {
        Text("Carpetas más grandes", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(6.dp))
        r.folders.forEach { StatRow(it.path, formatBytes(it.bytes, true)) }
        Spacer(Modifier.height(10.dp))
        Text("Subcarpetas más grandes", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(6.dp))
        r.subfolders.forEach { StatRow(it.path, formatBytes(it.bytes, true)) }
    }
    SysCard(Modifier.fillMaxWidth()) {
        Text("Archivos más grandes", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(6.dp))
        r.files.forEach { StatRow(it.path, formatBytes(it.bytes, true)) }
        Spacer(Modifier.height(8.dp))
        SmallNote(
            "${r.fileCount} archivos analizados en ${r.millis / 1000f} s. " +
                "Android bloquea Android/data y Android/obb aunque se conceda el permiso.",
        )
        Spacer(Modifier.height(8.dp))
        FilledTonalButton(onClick = onRescan) { Text("Volver a escanear") }
    }
    }
}
