package com.sysmon.monitor.core

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Ajustes locales (SharedPreferences). No se sincronizan ni se envían a ningún sitio. */
class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _autoUpdate = MutableStateFlow(prefs.getBoolean(KEY_AUTO, true))
    val autoUpdate: StateFlow<Boolean> = _autoUpdate.asStateFlow()

    private val _intervalMs = MutableStateFlow(prefs.getLong(KEY_INTERVAL, 2_000L))
    val intervalMs: StateFlow<Long> = _intervalMs.asStateFlow()

    fun setAutoUpdate(value: Boolean) {
        _autoUpdate.value = value
        prefs.edit().putBoolean(KEY_AUTO, value).apply()
    }

    fun setIntervalMs(value: Long) {
        _intervalMs.value = value
        prefs.edit().putLong(KEY_INTERVAL, value).apply()
    }

    companion object {
        private const val KEY_AUTO = "auto_update"
        private const val KEY_INTERVAL = "interval_ms"
        val INTERVAL_OPTIONS = listOf(1_000L, 2_000L, 3_000L, 5_000L, 10_000L)
    }
}
