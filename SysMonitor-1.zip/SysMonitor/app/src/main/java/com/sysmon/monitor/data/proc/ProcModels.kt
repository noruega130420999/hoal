package com.sysmon.monitor.data.proc

import android.system.Os
import android.system.OsConstants
import com.sysmon.monitor.data.ProcessGroup

data class ProcEntry(
    val pid: Int,
    val startTicks: Long,
    /** utime + stime acumulados, en ticks de reloj (normalmente 100 Hz). */
    val ticks: Long,
    val rssKb: Long,
    val name: String,
) {
    /** Clave estable frente a la reutilización de PIDs. */
    val key: Long get() = (pid.toLong() shl 40) or (startTicks and 0xFFFFFFFFFFL)
}

/** [cpu]: índice 0 = línea agregada "cpu", luego "cpu0", "cpu1"… Cada array: user nice system idle iowait irq softirq steal… */
class ProcSnapshot(
    val timeNanos: Long,
    val cpu: List<LongArray>,
    val procs: List<ProcEntry>,
)

fun LongArray.cpuTotal(): Long {
    var s = 0L
    for (i in 0 until minOf(size, 8)) s += this[i]
    return s
}

fun LongArray.cpuIdle(): Long = getOrElse(3) { 0L } + getOrElse(4) { 0L }

object ProcSnapshotParser {

    fun parse(text: String): ProcSnapshot? {
        var t = 0L
        val cpu = ArrayList<LongArray>()
        val procs = ArrayList<ProcEntry>()
        for (line in text.lineSequence()) {
            when {
                line.startsWith("T ") -> t = line.substring(2).trim().toLongOrNull() ?: 0L
                line.startsWith("C ") -> parseCpuLine(line.substring(2))?.let { cpu.add(it) }
                line.startsWith("P\t") -> {
                    val f = line.split('\t', limit = 6)
                    if (f.size == 6) {
                        val pid = f[1].toIntOrNull()
                        val ticks = f[2].toLongOrNull()
                        val rss = f[3].toLongOrNull()
                        val start = f[4].toLongOrNull()
                        if (pid != null && ticks != null && rss != null && start != null && f[5].isNotEmpty()) {
                            procs.add(ProcEntry(pid, start, ticks, rss, f[5]))
                        }
                    }
                }
            }
        }
        return if (cpu.isEmpty() && procs.isEmpty()) null else ProcSnapshot(t, cpu, procs)
    }

    /** "cpu0 123 4 56 …" → [123, 4, 56, …] */
    fun parseCpuLine(line: String): LongArray? {
        val parts = line.trim().split(Regex("\\s+"))
        if (parts.size < 5) return null
        return LongArray(parts.size - 1) { parts[it + 1].toLongOrNull() ?: 0L }
    }
}

/**
 * Convierte instantáneas consecutivas en CPU por proceso (como hace `top`).
 * CPU % = Δticks / (Δsegundos × CLK_TCK) × 100, es decir, % de UN núcleo.
 */
class ProcessSampler {
    private val clkTck: Double = try {
        Os.sysconf(OsConstants._SC_CLK_TCK).toDouble().takeIf { it > 0 } ?: 100.0
    } catch (e: Exception) {
        100.0
    }
    private var prevTime = 0L
    private var prevTicks: Map<Long, Long> = emptyMap()
    private var hasPrev = false

    fun reset() {
        hasPrev = false
        prevTicks = emptyMap()
    }

    fun update(s: ProcSnapshot): List<ProcessGroup> {
        val dtSec = if (hasPrev) (s.timeNanos - prevTime) / 1e9 else 0.0
        val ticksNow = HashMap<Long, Long>(s.procs.size * 2)

        class Acc {
            var rss = 0L
            var count = 0
            var dTicks = 0L
            var hasDelta = false
        }

        val groups = HashMap<String, Acc>()
        for (e in s.procs) {
            ticksNow[e.key] = e.ticks
            val id = e.name.substringBefore(':')
            val acc = groups.getOrPut(id) { Acc() }
            acc.rss += e.rssKb
            acc.count++
            if (dtSec > 0.2) {
                val old = prevTicks[e.key]
                if (old != null) {
                    acc.dTicks += (e.ticks - old).coerceAtLeast(0L)
                    acc.hasDelta = true
                }
            }
        }
        prevTime = s.timeNanos
        prevTicks = ticksNow
        hasPrev = true

        return groups.map { (id, a) ->
            ProcessGroup(
                id = id,
                cpuCorePercent = if (a.hasDelta) (a.dTicks / clkTck / dtSec * 100.0).toFloat() else null,
                rssKb = a.rss,
                processCount = a.count,
            )
        }
    }
}
