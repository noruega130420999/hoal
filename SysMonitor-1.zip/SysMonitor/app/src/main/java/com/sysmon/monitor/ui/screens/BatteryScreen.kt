package com.sysmon.monitor.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sysmon.monitor.core.Metric
import com.sysmon.monitor.core.formatDecimal
import com.sysmon.monitor.core.sourceOrNull
import com.sysmon.monitor.core.valueOrNull
import com.sysmon.monitor.data.BatteryInfo
import com.sysmon.monitor.shizuku.ShizukuState
import com.sysmon.monitor.ui.MainViewModel
import com.sysmon.monitor.ui.components.KeyValueRow
import com.sysmon.monitor.ui.components.LineChart
import com.sysmon.monitor.ui.components.SectionTitle
import com.sysmon.monitor.ui.components.SmallNote
import com.sysmon.monitor.ui.components.SourceBadge
import com.sysmon.monitor.ui.components.SysCard
import com.sysmon.monitor.ui.components.UnavailableBlock
import com.sysmon.monitor.ui.components.UsageBar
import com.sysmon.monitor.data.AppRow

@Composable
fun BatteryScreen(vm: MainViewModel, onAppClick: (AppRow) -> Unit) {
    val mon by vm.monitor.collectAsStateWithLifecycle()
    val usageState by vm.batteryUsage.collectAsStateWithLifecycle()
    val shizukuState by vm.shizuku.state.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { BatteryCard(mon.battery) }

        if (mon.batteryPowerHistory.size >= 2 || mon.batteryTempHistory.size >= 2) {
            item {
                SysCard(Modifier.fillMaxWidth()) {
                    if (mon.batteryPowerHistory.size >= 2) {
                        Text("Potencia (mW) · calculada", style = MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.height(4.dp))
                        LineChart(mon.batteryPowerHistory, maxY = null, color = MaterialTheme.colorScheme.tertiary)
                        Spacer(Modifier.height(12.dp))
                    }
                    if (mon.batteryTempHistory.size >= 2) {
                        Text("Temperatura (°C)", style = MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.height(4.dp))
                        LineChart(
                            mon.batteryTempHistory,
                            minY = (mon.batteryTempHistory.min() - 2f).coerceAtLeast(0f),
                            maxY = mon.batteryTempHistory.max() + 2f,
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                }
            }
        }

        item { SectionTitle("Consumo por aplicación") }

        if (shizukuState != ShizukuState.READY) {
            item { ShizukuCard(vm) }
            item {
                SysCard(Modifier.fillMaxWidth()) {
                    UnavailableBlock(
                        "Android no deja a una app normal leer el consumo de batería de las demás. " +
                            "Con Shizuku activo se lee la tabla «Estimated power use» de BatteryStats.",
                    )
                }
            }
        } else {
            item {
                SmallNote(
                    "Valores de BatteryStats del sistema: son ESTIMACIONES del propio Android " +
                        "(mAh atribuidos desde el último ciclo de carga), no una medición directa por app.",
                )
            }
            item {
                FilledTonalButton(onClick = { vm.refreshBatteryUsage() }, enabled = !usageState.loading) {
                    Text(if (usageState.loading) "Leyendo…" else "Actualizar consumo")
                }
            }
            val usage = usageState.usage
            if (usage == null && !usageState.loading) {
                item { UnavailableBlock(usageState.error ?: "Pulsa «Actualizar consumo».") }
            }
            if (usage != null) {
                usage.sinceLine?.let { item { SmallNote(it) } }
                val maxMah = usage.apps.firstOrNull()?.mah?.coerceAtLeast(0.001f) ?: 1f
                items(usage.apps.take(30)) { e ->
                    val row = if (e.packages.size == 1) apps.firstOrNull { it.packageName == e.packages[0] } else null
                    SysCard(Modifier.fillMaxWidth(), onClick = row?.let { r -> { onAppClick(r) } }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                e.displayName,
                                style = MaterialTheme.typography.titleSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f),
                            )
                            Text(formatDecimal(e.mah, 1) + " mAh", style = MaterialTheme.typography.titleSmall)
                        }
                        Spacer(Modifier.height(6.dp))
                        UsageBar(e.mah / maxMah, color = MaterialTheme.colorScheme.tertiary)
                    }
                }
                if (usage.components.isNotEmpty()) {
                    item { SectionTitle("Componentes del sistema") }
                    item {
                        SysCard(Modifier.fillMaxWidth()) {
                            usage.components.forEach { (name, mah) ->
                                StatRow(name, formatDecimal(mah, 1) + " mAh")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BatteryCard(b: BatteryInfo?) {
    SysCard(Modifier.fillMaxWidth()) {
        if (b == null) {
            SmallNote("Midiendo…")
            return@SysCard
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Batería", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            b.levelPercent.sourceOrNull()?.let { SourceBadge(it) }
        }
        Spacer(Modifier.height(8.dp))
        when (val l = b.levelPercent) {
            is Metric.Value -> {
                Text("${l.value}%", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(8.dp))
                UsageBar(l.value / 100f, color = MaterialTheme.colorScheme.secondary)
            }

            is Metric.Unavailable -> UnavailableBlock(l.reason)
        }
        Spacer(Modifier.height(8.dp))

        KeyValueRow("Estado", b.status, b.status.valueOrNull())
        KeyValueRow("Conexión", b.plugged, b.plugged.valueOrNull())
        KeyValueRow("Temperatura", b.temperatureC, b.temperatureC.valueOrNull()?.let { formatDecimal(it, 1) + " °C" })
        KeyValueRow("Voltaje", b.voltageMv, b.voltageMv.valueOrNull()?.let { formatDecimal(it / 1000f, 2) + " V" })
        KeyValueRow(
            if (b.charging) "Corriente de carga" else "Corriente de descarga",
            b.currentMa,
            b.currentMa.valueOrNull()?.let { formatDecimal(it, 0) + " mA" },
        )
        KeyValueRow("Potencia", b.powerMw, b.powerMw.valueOrNull()?.let { formatDecimal(it / 1000f, 2) + " W" })
        KeyValueRow("Carga restante", b.chargeCounterMah, b.chargeCounterMah.valueOrNull()?.let { formatDecimal(it, 0) + " mAh" })
        KeyValueRow("Tiempo restante", b.timeRemaining, b.timeRemaining.valueOrNull())
        KeyValueRow("Salud", b.health, b.health.valueOrNull())
        KeyValueRow("Ciclos de carga", b.cycleCount, b.cycleCount.valueOrNull()?.toString())
        KeyValueRow("Tecnología", b.technology, b.technology.valueOrNull())
        Spacer(Modifier.height(4.dp))
        SmallNote(
            "La insignia indica el origen: «Real» = lectura directa del sistema; «Calculado» = derivado de lecturas reales; " +
                "«Estimación» = proyección aproximada.",
        )
    }
}
