package com.sysmon.monitor.shizuku

import android.content.Context
import android.system.Os
import android.system.OsConstants
import java.io.File
import java.io.FileInputStream
import kotlin.system.exitProcess

/**
 * Se ejecuta en un proceso APARTE lanzado por Shizuku con el UID de shell (adb) o root.
 * Por eso no puede usar Context ni nada de la app: solo APIs de Java/Android básicas.
 *
 * Seguridad: solo expone dos lecturas con formato fijo. No ejecuta comandos arbitrarios,
 * no escribe nada y no mata procesos.
 */
class ShellUserService() : IShellService.Stub() {

    // Shizuku puede instanciar el servicio con o sin Context.
    @Suppress("UNUSED_PARAMETER")
    constructor(context: Context) : this()

    private var nameCache = HashMap<Long, String>()
    private val pageKb: Long = try {
        (Os.sysconf(OsConstants._SC_PAGESIZE) / 1024L).coerceAtLeast(1L)
    } catch (e: Exception) {
        4L
    }

    override fun destroy() {
        exitProcess(0)
    }

    /**
     * Formato (una entrada por línea):
     *   T <nanoTime>
     *   C cpu  <user> <nice> <system> <idle> <iowait> <irq> <softirq> <steal> ...
     *   P\t<pid>\t<ticks utime+stime>\t<rssKb>\t<startTicks>\t<nombre de proceso>
     */
    override fun readProcSnapshot(): String {
        val sb = StringBuilder(48 * 1024)
        sb.append("T ").append(System.nanoTime()).append('\n')

        try {
            File("/proc/stat").bufferedReader().use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    if (!line.startsWith("cpu")) break
                    sb.append("C ").append(line).append('\n')
                }
            }
        } catch (_: Exception) {
        }

        val newCache = HashMap<Long, String>(nameCache.size + 32)
        val entries = File("/proc").list() ?: emptyArray()
        for (n in entries) {
            if (n.isEmpty() || n[0] !in '0'..'9') continue
            val pid = n.toIntOrNull() ?: continue

            val stat = readText("/proc/$pid/stat") ?: continue
            val close = stat.lastIndexOf(')')
            if (close < 0 || close + 2 >= stat.length) continue
            // Tras ") " el primer campo es "state" (campo 3). utime=14 → [11], stime=15 → [12], starttime=22 → [19].
            val f = stat.substring(close + 2).split(' ')
            if (f.size < 20) continue
            val utime = f[11].toLongOrNull() ?: continue
            val stime = f[12].toLongOrNull() ?: continue
            val start = f[19].toLongOrNull() ?: continue

            val key = (pid.toLong() shl 40) or (start and 0xFFFFFFFFFFL)
            var name = nameCache[key]
            if (name == null) {
                name = readText("/proc/$pid/cmdline")?.substringBefore('\u0000')?.trim().orEmpty()
            }
            if (name.isEmpty()) continue // hilos del kernel: sin cmdline
            newCache[key] = name

            val residentPages = readText("/proc/$pid/statm")?.trim()?.split(' ')?.getOrNull(1)?.toLongOrNull() ?: 0L

            sb.append("P\t").append(pid)
                .append('\t').append(utime + stime)
                .append('\t').append(residentPages * pageKb)
                .append('\t').append(start)
                .append('\t').append(name)
                .append('\n')
        }
        nameCache = newCache
        return sb.toString()
    }

    /**
     * Consumo por UID según BatteryStats ("Estimated power use (mAh)"). Formato:
     *   S\t<línea "Time on battery: …">
     *   U\t<etiqueta de UID>\t<mAh>
     *   O\t<componente del sistema>\t<mAh>
     * Si el formato de esta versión/fabricante no se reconoce, devuelve una cadena vacía.
     */
    override fun readBatteryUsage(): String {
        val out = StringBuilder()
        var proc: Process? = null
        try {
            proc = ProcessBuilder("dumpsys", "batterystats").redirectErrorStream(true).start()
            var inSection = false
            var timeLine: String? = null
            proc.inputStream.bufferedReader().use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    if (!inSection) {
                        val t = line.trim()
                        if (timeLine == null && t.startsWith("Time on battery:")) {
                            timeLine = t
                            out.append("S\t").append(t).append('\n')
                        }
                        if (t.startsWith("Estimated power use (mAh)")) inSection = true
                        continue
                    }
                    // Fin de la sección: línea en blanco o sin sangría.
                    if (line.isBlank() || !line[0].isWhitespace()) break

                    val uid = UID_REGEX.find(line)
                    if (uid != null) {
                        out.append("U\t").append(uid.groupValues[1]).append('\t').append(uid.groupValues[2]).append('\n')
                        continue
                    }
                    val comp = COMPONENT_REGEX.find(line)
                    if (comp != null) {
                        val name = comp.groupValues[1].trim()
                        if (!name.equals("Capacity", ignoreCase = true)) {
                            out.append("O\t").append(name).append('\t').append(comp.groupValues[2]).append('\n')
                        }
                    }
                }
            }
        } catch (_: Exception) {
        } finally {
            try {
                proc?.destroy()
            } catch (_: Exception) {
            }
        }
        return out.toString()
    }

    private fun readText(path: String): String? = try {
        FileInputStream(path).use { String(it.readBytes()) }
    } catch (e: Exception) {
        null
    }

    private companion object {
        val UID_REGEX = Regex("""^\s*uid\s+(\S+?):\s+([0-9]+(?:\.[0-9]+)?)""", RegexOption.IGNORE_CASE)
        val COMPONENT_REGEX = Regex("""^\s+([A-Za-z][^:()]{1,40}?):\s+([0-9]+(?:\.[0-9]+)?)""")
    }
}
