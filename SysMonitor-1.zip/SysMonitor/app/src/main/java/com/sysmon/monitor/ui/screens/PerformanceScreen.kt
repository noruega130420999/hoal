package com.sysmon.monitor.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sysmon.monitor.core.Metric
import com.sysmon.monitor.core.formatKb
import com.sysmon.monitor.core.formatPercent
import com.sysmon.monitor.core.formatPercent1
import com.sysmon.monitor.core.formatBytes
import com.sysmon.monitor.core.sourceOrNull
import com.sysmon.monitor.core.valueOrNull
import com.sysmon.monitor.data.AppRow
import com.sysmon.monitor.data.CpuInfo
import com.sysmon.monitor.data.RamInfo
import com.sysmon.monitor.shizuku.ShizukuState
import com.sysmon.monitor.ui.MainViewModel
import com.sysmon.monitor.ui.MonitorState
import com.sysmon.monitor.ui.components.ChipRow
import com.sysmon.monitor.ui.components.KeyValueRow
import com.sysmon.monitor.ui.components.LineChart
import com.sysmon.monitor.ui.components.SectionTitle
import com.sysmon.monitor.ui.components.SmallNote
import com.sysmon.monitor.ui.components.SourceBadge
import com.sysmon.monitor.ui.components.SysCard
import com.sysmon.monitor.ui.components.SysIcons
import com.sysmon.monitor.ui.components.UnavailableBlock
import com.sysmon.monitor.ui.components.UsageBar
import kotlin.math.roundToInt

@Composable
fun PerformanceScreen(
    vm: MainViewModel,
    onOpenTab: (Int) -> Unit,
    onAppClick: (AppRow) -> Unit,
) {
    val mon by vm.monitor.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()
    val shizukuState by vm.shizuku.state.collectAsStateWithLifecycle()
    var sortByRam by rememberSaveable { mutableStateOf(false) }

    val top = remember(apps, sortByRam) {
        apps.asSequence()
            .filter { it.running == true }
            .sortedByDescending {
                if (sortByRam) (it.ramKb ?: -1L).toFloat() else (it.cpuCorePercent ?: -1f)
            }
            .take(15)
            .toList()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { SummaryGrid(mon, onOpenTab) }
        item { CpuCard(mon.cpu, mon.cpuHistory) }
        item { RamCard(mon.ram, mon.ramHistory) }

        item { SectionTitle("Procesos y aplicaciones en ejecución") }

        if (shizukuState != ShizukuState.READY) {
            item { ShizukuCard(vm) }
            item {
                SysCard(Modifier.fillMaxWidth()) {
                    Text("CPU y RAM por aplicación", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(4.dp))
                    UnavailableBlock(
                        "Android no permite a una app normal ver los procesos de otras apps. " +
                            "Con Shizuku activo se muestran aquí.",
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("Esta app (SysMonitor)", style = MaterialTheme.typography.titleSmall)
                    val self = mon.cpu?.selfPercentOfCore
                    SmallNote(
                        "CPU: " + (self?.let { formatPercent1(it) } ?: "midiendo…") +
                            " · RAM (PSS): " + (mon.selfPssKb?.let { formatKb(it) } ?: ND),
                    )
                }
            }
        } else {
            item {
                ChipRow(
                    options = listOf(false to "Ordenar por CPU", true to "Ordenar por RAM"),
                    selected = sortByRam,
                    onSelect = { sortByRam = it },
                )
            }
            item {
                SmallNote(
                    "CPU: 100 % = un núcleo completo (como `top`). RAM: memoria residente (RSS), " +
                        "incluye páginas compartidas. Datos reales vía Shizuku.",
                )
            }
            if (top.isEmpty()) {
                item { SmallNote("Midiendo… la CPU por proceso aparece tras la segunda muestra.") }
            }
            items(top, key = { it.packageName }) { row ->
                ProcessRow(row, sortByRam) { onAppClick(row) }
            }
        }
    }
}

// ------------------------------------------------------------------ tarjetas resumen

@Composable
private fun SummaryGrid(mon: MonitorState, onOpenTab: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme

    val cpuTotal = mon.cpu?.totalPercent
    val cpuValue = cpuTotal?.valueOrNull()
    val cpuDetail = when (cpuTotal) {
        null -> "…"
        is Metric.Value -> "${mon.cpu?.coreCount ?: 0} núcleos"
        is Metric.Unavailable -> if (cpuTotal.reason.startsWith("Midiendo")) "Midiendo…" else "Requiere Shizuku"
    }

    val ram = mon.ram?.valueOrNull()
    val storage = mon.storage?.valueOrNull()
    val bat = mon.battery
    val level = bat?.levelPercent?.valueOrNull()
    val temp = bat?.temperatureC?.valueOrNull()
    val batColor = when {
        level == null -> cs.onSurfaceVariant
        level <= 15 -> cs.error
        level <= 30 -> cs.tertiary
        else -> cs.secondary
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            Modifier.fillMaxWidth().height(IntrinsicSize.Min),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SummaryCard(
                title = "CPU",
                icon = SysIcons.Chip,
                value = cpuValue?.let { formatPercent(it) } ?: "No disponible",
                detail = cpuDetail,
                progress = cpuValue?.div(100f),
                color = cs.primary,
                modifier = Modifier.weight(1f).fillMaxHeight(),
            )
            SummaryCard(
                title = "RAM",
                icon = SysIcons.Chip,
                value = ram?.let { formatKb(it.usedKb) } ?: "No disponible",
                detail = ram?.let { "de ${formatKb(it.totalKb)}" } ?: "…",
                progress = ram?.let { if (it.totalKb > 0) it.usedKb.toFloat() / it.totalKb else null },
                color = cs.secondary,
                modifier = Modifier.weight(1f).fillMaxHeight(),
            )
        }
        Row(
            Modifier.fillMaxWidth().height(IntrinsicSize.Min),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SummaryCard(
                title = "Almacenamiento",
                icon = SysIcons.Storage,
                value = storage?.let { formatBytes(it.usedBytes, decimal = true) } ?: "No disponible",
                detail = storage?.let { "de ${formatBytes(it.totalBytes, decimal = true)}" } ?: "…",
                progress = storage?.let { if (it.totalBytes > 0) it.usedBytes.toFloat() / it.totalBytes else null },
                color = cs.tertiary,
                modifier = Modifier.weight(1f).fillMaxHeight(),
                onClick = { onOpenTab(1) },
            )
            SummaryCard(
                title = "Batería",
                icon = SysIcons.Battery,
                value = level?.let { "$it%" } ?: "No disponible",
                detail = listOfNotNull(
                    temp?.let { String.format("%.1f °C", it) },
                    bat?.status?.valueOrNull(),
                ).joinToString(" · ").ifEmpty { "…" },
                progress = level?.div(100f),
                color = batColor,
                modifier = Modifier.weight(1f).fillMaxHeight(),
                onClick = { onOpenTab(2) },
            )
        }
    }
}

@Composable
private fun SummaryCard(
    title: String,
    icon: ImageVector,
    value: String,
    detail: String,
    progress: Float?,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
) {
    SysCard(modifier, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.width(18.dp).height(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                title,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            value,
            style = if (value == "No disponible") MaterialTheme.typography.titleMedium else MaterialTheme.typography.headlineSmall,
            color = if (value == "No disponible") MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
        )
        SmallNote(detail)
        if (progress != null) {
            Spacer(Modifier.height(8.dp))
            UsageBar(progress, color = color)
        }
    }
}

// ------------------------------------------------------------------ CPU

@Composable
private fun CpuCard(cpu: CpuInfo?, history: List<Float>) {
    SysCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("CPU", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            cpu?.totalPercent?.sourceOrNull()?.let { SourceBadge(it) }
        }
        Spacer(Modifier.height(8.dp))

        when (val t = cpu?.totalPercent) {
            null -> SmallNote("Midiendo…")
            is Metric.Value -> Text(formatPercent1(t.value), style = MaterialTheme.typography.headlineMedium)
            is Metric.Unavailable -> UnavailableBlock(t.reason)
        }

        if (history.size >= 2) {
            Spacer(Modifier.height(8.dp))
            LineChart(history, color = MaterialTheme.colorScheme.primary)
        }

        if (cpu != null) {
            val per = cpu.perCorePercent.valueOrNull()
            val freqs = cpu.frequenciesMhz.valueOrNull()
            if (per != null || freqs != null) {
                Spacer(Modifier.height(12.dp))
                Text("Por núcleo", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(4.dp))
                for (i in 0 until cpu.coreCount) {
                    CoreRow(i, per?.getOrNull(i), freqs?.getOrNull(i))
                }
            }
            val fm = cpu.frequenciesMhz
            if (fm is Metric.Unavailable) {
                Spacer(Modifier.height(8.dp))
                SmallNote("Frecuencia por núcleo: No disponible. ${fm.reason}")
            }
            Spacer(Modifier.height(4.dp))
            KeyValueRow("Estado térmico", cpu.thermal, cpu.thermal.valueOrNull())
        }
    }
}

@Composable
private fun CoreRow(index: Int, percent: Float?, freqMhz: Int?) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("N$index", style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(30.dp))
        Box(Modifier.weight(1f)) {
            if (percent != null) UsageBar(percent / 100f)
        }
        Text(
            percent?.let { formatPercent(it) } ?: "",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.width(48.dp).padding(start = 8.dp),
        )
        Text(
            freqMhz?.let { "$it MHz" } ?: "apagado",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(76.dp),
        )
    }
}

// ------------------------------------------------------------------ RAM

@Composable
private fun RamCard(ram: Metric<RamInfo>?, history: List<Float>) {
    SysCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("RAM", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            ram?.sourceOrNull()?.let { SourceBadge(it) }
        }
        Spacer(Modifier.height(8.dp))
        when (ram) {
            null -> SmallNote("Midiendo…")
            is Metric.Unavailable -> UnavailableBlock(ram.reason)
            is Metric.Value -> {
                val r = ram.value
                Text(
                    "${formatKb(r.usedKb)} / ${formatKb(r.totalKb)}",
                    style = MaterialTheme.typography.headlineSmall,
                )
                Spacer(Modifier.height(8.dp))
                if (r.totalKb > 0) {
                    UsageBar(r.usedKb.toFloat() / r.totalKb, color = MaterialTheme.colorScheme.secondary)
                }
                if (history.size >= 2) {
                    Spacer(Modifier.height(8.dp))
                    LineChart(history, color = MaterialTheme.colorScheme.secondary)
                }
                Spacer(Modifier.height(8.dp))
                StatRow("Usada", formatKb(r.usedKb) + if (r.totalKb > 0) " (${(r.usedKb * 100f / r.totalKb).roundToInt()} %)" else "")
                StatRow("Disponible", formatKb(r.availableKb))
                StatRow("Caché y búferes", formatKb(r.cachedKb))
                if (r.swapTotalKb > 0) {
                    StatRow("Swap / zRAM usada", "${formatKb(r.swapUsedKb)} de ${formatKb(r.swapTotalKb)}")
                }
                if (r.lowMemory) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "El sistema indica memoria baja.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------ lista de procesos

@Composable
private fun ProcessRow(row: AppRow, sortByRam: Boolean, onClick: () -> Unit) {
    SysCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                row.label,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Text(
                if (sortByRam) row.ramText() else row.cpuText(),
                style = MaterialTheme.typography.titleSmall,
            )
        }
        SmallNote("CPU ${row.cpuText()} · RAM ${row.ramText()}" + if (row.isSystem) " · Sistema" else "")
    }
}
