package com.sysmon.monitor.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sysmon.monitor.core.launchSafely
import com.sysmon.monitor.shizuku.ShizukuController
import com.sysmon.monitor.shizuku.ShizukuState
import com.sysmon.monitor.ui.MainViewModel
import com.sysmon.monitor.ui.components.SmallNote
import com.sysmon.monitor.ui.components.SysCard

private class Cta(val message: String, val label: String?, val action: (() -> Unit)?)

/** Estado de Shizuku con el paso siguiente que debe dar el usuario. */
@Composable
fun ShizukuCard(vm: MainViewModel, modifier: Modifier = Modifier) {
    val state by vm.shizuku.state.collectAsStateWithLifecycle()
    val privilege by vm.shizuku.privilege.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    val cta = when (state) {
        ShizukuState.NOT_INSTALLED -> Cta(
            "Shizuku no está instalado. Es opcional: añade CPU total, procesos, RAM por app y consumo de batería por app.",
            "Descargar Shizuku",
        ) { ctx.launchSafely(Intent(Intent.ACTION_VIEW, Uri.parse(ShizukuController.DOWNLOAD_URL))) }

        ShizukuState.NOT_RUNNING -> Cta(
            "Shizuku está instalado pero no se está ejecutando. Ábrelo e inícialo (depuración inalámbrica).",
            "Abrir Shizuku",
        ) { vm.shizuku.launchIntent()?.let { ctx.launchSafely(it) } }

        ShizukuState.UNSUPPORTED -> Cta(
            "La versión de Shizuku instalada no es compatible. Actualízala desde su web.",
            null,
            null,
        )

        ShizukuState.NEEDS_PERMISSION -> Cta(
            "Shizuku está activo. Concede el permiso a SysMonitor. Si no aparece el diálogo, ábrelo en Shizuku → Aplicaciones autorizadas.",
            "Conceder permiso",
        ) { vm.shizuku.requestPermission() }

        ShizukuState.CONNECTING -> Cta("Conectando con Shizuku…", null, null)

        ShizukuState.READY -> Cta(
            "Shizuku activo (${privilege ?: "…"}). Datos por proceso y por app habilitados.",
            null,
            null,
        )
    }

    SysCard(modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Shizuku (opcional)", style = MaterialTheme.typography.titleSmall)
                SmallNote(cta.message)
            }
        }
        if (cta.label != null && cta.action != null) {
            Spacer(Modifier.height(10.dp))
            FilledTonalButton(onClick = cta.action) { Text(cta.label) }
        }
    }
}
