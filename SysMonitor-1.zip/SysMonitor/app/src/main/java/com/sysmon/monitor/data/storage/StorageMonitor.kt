package com.sysmon.monitor.data.storage

import android.app.usage.StorageStatsManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.os.storage.StorageManager
import com.sysmon.monitor.core.Metric
import com.sysmon.monitor.core.Permissions
import com.sysmon.monitor.core.Source
import com.sysmon.monitor.data.AppStorage
import com.sysmon.monitor.data.VolumeInfo

class StorageMonitor(private val context: Context) {

    /** Capacidad total/libre del almacenamiento interno, igual que la que muestran los Ajustes. */
    fun internal(): Metric<VolumeInfo> {
        return try {
            val ssm = context.getSystemService(StorageStatsManager::class.java)
            Metric.Value(
                VolumeInfo(
                    name = "Almacenamiento interno",
                    totalBytes = ssm.getTotalBytes(StorageManager.UUID_DEFAULT),
                    freeBytes = ssm.getFreeBytes(StorageManager.UUID_DEFAULT),
                    removable = false,
                ),
                Source.SYSTEM_API,
            )
        } catch (e: Exception) {
            try {
                val st = StatFs(Environment.getDataDirectory().path)
                Metric.Value(
                    VolumeInfo("Almacenamiento interno", st.totalBytes, st.availableBytes, false),
                    Source.SYSTEM_API,
                )
            } catch (e2: Exception) {
                Metric.Unavailable("No se pudo leer el almacenamiento.")
            }
        }
    }

    /** Tarjetas SD u otros volúmenes montados. */
    fun removableVolumes(): List<VolumeInfo> {
        if (Build.VERSION.SDK_INT < 30) return emptyList()
        return try {
            val sm = context.getSystemService(StorageManager::class.java)
            sm.storageVolumes
                .filter { !it.isPrimary && it.state == Environment.MEDIA_MOUNTED }
                .mapNotNull { v ->
                    val dir = v.directory ?: return@mapNotNull null
                    try {
                        val st = StatFs(dir.path)
                        VolumeInfo(v.getDescription(context), st.totalBytes, st.availableBytes, v.isRemovable)
                    } catch (e: Exception) {
                        null
                    }
                }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Tamaño de app, datos y caché de cada paquete. Requiere "Acceso de uso".
     * Devuelve null si el permiso no está concedido.
     */
    fun queryAppStorage(packages: List<String>): Map<String, AppStorage>? {
        if (!Permissions.hasUsageAccess(context)) return null
        val ssm = context.getSystemService(StorageStatsManager::class.java) ?: return null
        val user = Process.myUserHandle()
        val out = HashMap<String, AppStorage>(packages.size * 2)
        for (pkg in packages) {
            try {
                val s = ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, pkg, user)
                out[pkg] = AppStorage(s.appBytes, s.dataBytes, s.cacheBytes)
            } catch (e: Exception) {
                // Paquete sin datos para este usuario o no consultable: se queda como "No disponible".
            }
        }
        return out
    }
}
