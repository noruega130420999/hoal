package com.sysmon.monitor.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF6CB6FF),
    onPrimary = Color(0xFF00213A),
    secondary = Color(0xFF7BD8A8),
    onSecondary = Color(0xFF00210F),
    tertiary = Color(0xFFFFB86B),
    onTertiary = Color(0xFF2B1700),
    background = Color(0xFF0B0C0F),
    onBackground = Color(0xFFE6E8EB),
    surface = Color(0xFF14161A),
    onSurface = Color(0xFFE6E8EB),
    surfaceVariant = Color(0xFF22262C),
    onSurfaceVariant = Color(0xFFA9AFB8),
    outline = Color(0xFF3A3F47),
    error = Color(0xFFFF6B6B),
)

/** Siempre oscuro, sin transiciones ni animaciones llamativas. */
@Composable
fun SysMonTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
