package com.sysmon.monitor.data.battery

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import com.sysmon.monitor.core.Metric
import com.sysmon.monitor.core.Source
import com.sysmon.monitor.core.formatDurationMs
import com.sysmon.monitor.data.BatteryInfo
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Estado de la batería con APIs oficiales (BatteryManager + intent ACTION_BATTERY_CHANGED).
 * Todo lo que no sea una lectura directa se marca como "Calculado" o "Estimación".
 */
class BatteryMonitor(private val context: Context) {
    private val bm = context.getSystemService(BatteryManager::class.java)
    private var emaMa: Float? = null

    fun read(): BatteryInfo {
        val i: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

        // Nivel
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val levelMetric: Metric<Int> = if (level >= 0 && scale > 0) {
            Metric.Value((level * 100f / scale).roundToInt(), Source.SYSTEM_API)
        } else {
            Metric.Unavailable("El sistema no informa del nivel.")
        }

        // Estado de carga
        val statusCode = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = statusCode == BatteryManager.BATTERY_STATUS_CHARGING
        val full = statusCode == BatteryManager.BATTERY_STATUS_FULL
        val status: Metric<String> = when (statusCode) {
            BatteryManager.BATTERY_STATUS_CHARGING -> Metric.Value("Cargando", Source.SYSTEM_API)
            BatteryManager.BATTERY_STATUS_DISCHARGING -> Metric.Value("Descargando", Source.SYSTEM_API)
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> Metric.Value("Conectada, sin cargar", Source.SYSTEM_API)
            BatteryManager.BATTERY_STATUS_FULL -> Metric.Value("Completa", Source.SYSTEM_API)
            else -> Metric.Unavailable("Estado desconocido.")
        }

        // Conexión
        val pluggedCode = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val pluggedText = buildList {
            if (pluggedCode and BatteryManager.BATTERY_PLUGGED_AC != 0) add("Corriente (AC)")
            if (pluggedCode and BatteryManager.BATTERY_PLUGGED_USB != 0) add("USB")
            if (pluggedCode and BatteryManager.BATTERY_PLUGGED_WIRELESS != 0) add("Inalámbrica")
        }.joinToString(" + ").ifEmpty { "No conectado" }

        // Temperatura (décimas de °C)
        val tempRaw = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val temp: Metric<Float> = if (tempRaw != Int.MIN_VALUE) {
            Metric.Value(tempRaw / 10f, Source.SYSTEM_API)
        } else {
            Metric.Unavailable("El sistema no informa de la temperatura.")
        }

        // Voltaje
        val mv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val voltage: Metric<Int> = if (mv > 0) {
            Metric.Value(mv, Source.SYSTEM_API)
        } else {
            Metric.Unavailable("El sistema no informa del voltaje.")
        }

        // Salud
        val health: Metric<String> = when (i?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> Metric.Value("Buena", Source.SYSTEM_API)
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> Metric.Value("Sobrecalentada", Source.SYSTEM_API)
            BatteryManager.BATTERY_HEALTH_DEAD -> Metric.Value("Dañada", Source.SYSTEM_API)
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> Metric.Value("Sobrevoltaje", Source.SYSTEM_API)
            BatteryManager.BATTERY_HEALTH_COLD -> Metric.Value("Fría", Source.SYSTEM_API)
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> Metric.Value("Fallo no especificado", Source.SYSTEM_API)
            else -> Metric.Unavailable("El sistema no informa de la salud.")
        }

        val techStr = i?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY)
        val technology: Metric<String> = if (!techStr.isNullOrBlank()) {
            Metric.Value(techStr, Source.SYSTEM_API)
        } else {
            Metric.Unavailable("No informado.")
        }

        val cycles = i?.getIntExtra(EXTRA_CYCLE_COUNT, -1) ?: -1
        val cycleCount: Metric<Int> = if (cycles > 0) {
            Metric.Value(cycles, Source.SYSTEM_API)
        } else {
            Metric.Unavailable("Samsung no expone el recuento de ciclos a las apps.")
        }

        // Corriente instantánea. Unidad oficial de la API: microamperios (µA). Se muestra la magnitud;
        // el signo del valor varía según el fabricante, por eso no se usa para decidir carga/descarga.
        val raw = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        val currentMa: Metric<Float>
        if (raw == Int.MIN_VALUE || raw == 0) {
            currentMa = Metric.Unavailable("El dispositivo no informa de la corriente.")
            emaMa = null
        } else {
            val ma = abs(raw) / 1000f
            currentMa = Metric.Value(ma, Source.SYSTEM_API)
            emaMa = emaMa?.let { it * 0.8f + ma * 0.2f } ?: ma
        }

        // Potencia = |I| × V (calculada)
        val powerMw: Metric<Float> = if (currentMa is Metric.Value && voltage is Metric.Value) {
            Metric.Value(currentMa.value * voltage.value / 1000f, Source.CALCULATED)
        } else {
            Metric.Unavailable("Necesita corriente y voltaje.")
        }

        // Carga restante en mAh
        val counterUah = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        val chargeCounter: Metric<Float> = if (counterUah != Int.MIN_VALUE && counterUah > 0) {
            Metric.Value(counterUah / 1000f, Source.SYSTEM_API)
        } else {
            Metric.Unavailable("El dispositivo no informa de la carga en mAh.")
        }

        // Tiempo restante
        val timeRemaining: Metric<String> = when {
            charging -> {
                val ms = try {
                    bm.computeChargeTimeRemaining()
                } catch (e: Exception) {
                    -1L
                }
                if (ms > 0) {
                    Metric.Value(formatDurationMs(ms) + " hasta la carga completa", Source.ESTIMATE)
                } else {
                    Metric.Unavailable("El sistema aún no estima el tiempo de carga.")
                }
            }

            full -> Metric.Unavailable("Batería completa.")

            chargeCounter is Metric.Value && emaMa != null && emaMa!! > 20f && pluggedCode == 0 -> {
                val hours = chargeCounter.value / emaMa!!
                Metric.Value(formatDurationMs((hours * 3_600_000f).toLong()) + " al ritmo actual", Source.ESTIMATE)
            }

            else -> Metric.Unavailable("No hay datos suficientes para estimarlo.")
        }

        return BatteryInfo(
            levelPercent = levelMetric,
            status = status,
            charging = charging,
            plugged = Metric.Value(pluggedText, Source.SYSTEM_API),
            temperatureC = temp,
            voltageMv = voltage,
            health = health,
            technology = technology,
            currentMa = currentMa,
            powerMw = powerMw,
            chargeCounterMah = chargeCounter,
            timeRemaining = timeRemaining,
            cycleCount = cycleCount,
        )
    }

    private companion object {
        // BatteryManager.EXTRA_CYCLE_COUNT (API 34); se usa la cadena para compilar contra cualquier SDK.
        const val EXTRA_CYCLE_COUNT = "android.os.extra.CYCLE_COUNT"
    }
}
