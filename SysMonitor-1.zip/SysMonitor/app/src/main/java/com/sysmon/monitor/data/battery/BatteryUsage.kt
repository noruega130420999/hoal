package com.sysmon.monitor.data.battery

import android.content.pm.PackageManager
import com.sysmon.monitor.data.apps.AppCatalog

/** Consumo de un UID según BatteryStats. [mah] es una estimación del sistema, no una medición directa. */
data class BatteryEntry(
    val uidLabel: String,
    val displayName: String,
    val packages: List<String>,
    val mah: Float,
)

data class BatteryUsage(
    val apps: List<BatteryEntry>,
    val components: List<Pair<String, Float>>,
    val sinceLine: String?,
)

class BatteryUsageParser(
    private val pm: PackageManager,
    private val catalog: AppCatalog,
) {
    fun parse(raw: String): BatteryUsage? {
        if (raw.isBlank()) return null
        val apps = ArrayList<BatteryEntry>()
        val comps = ArrayList<Pair<String, Float>>()
        var since: String? = null
        for (line in raw.lineSequence()) {
            val f = line.split('\t')
            when (f.firstOrNull()) {
                "S" -> if (f.size >= 2) since = f[1]
                "U" -> if (f.size >= 3) {
                    val mah = f[2].toFloatOrNull() ?: continue
                    val (pkgs, name) = resolve(f[1])
                    apps.add(BatteryEntry(f[1], name, pkgs, mah))
                }
                "O" -> if (f.size >= 3) {
                    val mah = f[2].toFloatOrNull() ?: continue
                    comps.add(f[1] to mah)
                }
            }
        }
        if (apps.isEmpty() && comps.isEmpty()) return null
        return BatteryUsage(
            apps = apps.sortedByDescending { it.mah },
            components = comps.sortedByDescending { it.second },
            sinceLine = since,
        )
    }

    private fun uidFrom(label: String): Int? {
        label.toIntOrNull()?.let { return it }
        // u0a123 → 10123 ; u10a123 → 1010123 (otros usuarios)
        USER_APP.matchEntire(label)?.let {
            return it.groupValues[1].toInt() * 100_000 + 10_000 + it.groupValues[2].toInt()
        }
        return when (label) {
            "root" -> 0
            "system" -> 1000
            "shell" -> 2000
            else -> null
        }
    }

    private fun resolve(label: String): Pair<List<String>, String> {
        val uid = uidFrom(label)
        if (uid == 1000) return emptyList<String>() to "Sistema Android (UID compartido)"
        val pkgs = try {
            uid?.let { pm.getPackagesForUid(it)?.toList() }.orEmpty()
        } catch (e: Exception) {
            emptyList()
        }
        val first = pkgs.firstOrNull()
        val name = when {
            pkgs.size == 1 -> catalog.byPackage[first]?.label ?: first!!
            pkgs.size > 1 -> (catalog.byPackage[first]?.label ?: first!!) + " +${pkgs.size - 1} (UID compartido)"
            else -> "UID $label"
        }
        return pkgs to name
    }

    private companion object {
        val USER_APP = Regex("""^u(\d+)a(\d+)$""")
    }
}
