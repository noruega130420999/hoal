package com.sysmon.monitor.core

/**
 * Origen de cada cifra mostrada. Permite distinguir datos reales del sistema de cálculos y estimaciones.
 */
enum class Source(val label: String) {
    SYSTEM_API("Real · API de Android"),
    SYSTEM_FILE("Real · archivo del sistema"),
    SHIZUKU("Real · Shizuku"),
    CALCULATED("Calculado"),
    ESTIMATE("Estimación"),
}

/**
 * Una métrica o bien tiene un valor medido (con su origen) o bien no está disponible.
 * Nunca se rellena con datos inventados.
 */
sealed interface Metric<out T> {
    data class Value<T>(val value: T, val source: Source) : Metric<T>
    data class Unavailable(val reason: String) : Metric<Nothing>
}

fun <T> Metric<T>.valueOrNull(): T? = (this as? Metric.Value<T>)?.value

fun Metric<*>.sourceOrNull(): Source? = (this as? Metric.Value<*>)?.source
