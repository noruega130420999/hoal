package com.sysmon.monitor.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sysmon.monitor.core.AppSettings
import com.sysmon.monitor.core.Permissions
import com.sysmon.monitor.core.formatBytes
import com.sysmon.monitor.core.launchSafely
import com.sysmon.monitor.data.AppRow
import com.sysmon.monitor.ui.components.ChipRow
import com.sysmon.monitor.ui.components.SmallNote
import com.sysmon.monitor.ui.components.SysIcons
import com.sysmon.monitor.ui.screens.AppsScreen
import com.sysmon.monitor.ui.screens.BatteryScreen
import com.sysmon.monitor.ui.screens.PerformanceScreen
import com.sysmon.monitor.ui.screens.ShizukuCard
import com.sysmon.monitor.ui.screens.StatRow
import com.sysmon.monitor.ui.screens.StorageScreen
import com.sysmon.monitor.ui.screens.batteryText
import com.sysmon.monitor.ui.screens.cpuText
import com.sysmon.monitor.ui.screens.foregroundText
import com.sysmon.monitor.ui.screens.ramText
import androidx.compose.ui.graphics.vector.ImageVector

private data class TabDef(val title: String, val icon: ImageVector)

private val TABS = listOf(
    TabDef("Rendimiento", SysIcons.Chip),
    TabDef("Almacenamiento", SysIcons.Storage),
    TabDef("Batería", SysIcons.Battery),
    TabDef("Aplicaciones", SysIcons.Phone),
)

@Composable
fun AppRoot(vm: MainViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<AppRow?>(null) }
    var showSettings by rememberSaveable { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(start = 16.dp, end = 8.dp, top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(TABS[tab].title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                TextButton(onClick = { vm.refreshNow() }) { Text("Actualizar") }
                TextButton(onClick = { showSettings = true }) { Text("Ajustes") }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                TABS.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = t.title) },
                        label = { Text(t.title, maxLines = 1, style = MaterialTheme.typography.labelSmall) },
                    )
                }
            }
        },
    ) { padding ->
        Column(Modifier.padding(padding)) {
            when (tab) {
                0 -> PerformanceScreen(vm, onOpenTab = { tab = it }, onAppClick = { selected = it })
                1 -> StorageScreen(vm, onAppClick = { selected = it })
                2 -> BatteryScreen(vm, onAppClick = { selected = it })
                else -> AppsScreen(vm, onAppClick = { selected = it })
            }
        }
    }

    selected?.let { row ->
        AppDetailSheet(row = row, onDismiss = { selected = null })
    }
    if (showSettings) {
        SettingsDialog(vm, onDismiss = { showSettings = false })
    }
}

// ------------------------------------------------------------------ detalle de app

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppDetailSheet(row: AppRow, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = MaterialTheme.colorScheme.surface) {
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 20.dp).padding(bottom = 16.dp)
                .verticalScroll(rememberScrollState()),
        ) {
            Text(row.label, style = MaterialTheme.typography.titleLarge)
            SmallNote(row.packageName + if (row.isSystem) " · App del sistema" else "")
            Spacer(Modifier.height(12.dp))
            StatRow("CPU (% de un núcleo)", row.cpuText())
            StatRow("RAM (RSS)", row.ramText())
            StatRow("En ejecución", when (row.running) { true -> "Sí"; false -> "No"; null -> "N/D" })
            StatRow("Tamaño de la app", row.storage?.let { formatBytes(it.appBytes, true) } ?: "N/D")
            StatRow("Datos (incluye caché)", row.storage?.let { formatBytes(it.dataBytes, true) } ?: "N/D")
            StatRow("Caché", row.storage?.let { formatBytes(it.cacheBytes, true) } ?: "N/D")
            StatRow("Batería (estimación del sistema)", row.batteryText())
            StatRow("Tiempo en primer plano (24 h)", row.foregroundText())
            Spacer(Modifier.height(4.dp))
            SmallNote("N/D = No disponible con los permisos actuales.")
            Spacer(Modifier.height(12.dp))
            if (row.installed) {
                FilledTonalButton(
                    onClick = { ctx.launchSafely(Permissions.appDetailsIntent(row.packageName)) },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Abrir ajustes de la app (almacenamiento, forzar detención…)") }
                SmallNote(
                    "Desde los Ajustes de Android puedes borrar caché o datos. SysMonitor nunca cierra procesos ni modifica nada por sí sola.",
                    Modifier.padding(top = 6.dp),
                )
            } else {
                SmallNote("Proceso nativo del sistema: no es un paquete instalable.")
            }
        }
    }
}

// ------------------------------------------------------------------ ajustes

@Composable
private fun SettingsDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val auto by vm.settings.autoUpdate.collectAsStateWithLifecycle()
    val interval by vm.settings.intervalMs.collectAsStateWithLifecycle()
    val perms by vm.perms.collectAsStateWithLifecycle()

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } },
        title = { Text("Ajustes") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Actualización automática", Modifier.weight(1f))
                    Switch(checked = auto, onCheckedChange = { vm.setAutoUpdate(it) })
                }
                if (auto) {
                    SmallNote("Intervalo")
                    ChipRow(
                        options = AppSettings.INTERVAL_OPTIONS.map { it to "${it / 1000} s" },
                        selected = interval,
                        onSelect = { vm.setIntervalMs(it) },
                    )
                } else {
                    SmallNote("Desactivada: usa «Actualizar» para medir de nuevo.")
                }
                SmallNote("Solo se mide con la app visible; en segundo plano no se consume CPU ni batería.")

                Text("Permisos", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Acceso de uso: " + if (perms.usageAccess) "concedido" else "no concedido",
                        Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    if (!perms.usageAccess) {
                        TextButton(onClick = {
                            ctx.launchSafely(Permissions.usageAccessIntent(ctx), Permissions.usageAccessFallbackIntent())
                        }) { Text("Conceder") }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Acceso a archivos: " + if (perms.allFiles) "concedido" else "no concedido",
                        Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    if (!perms.allFiles) {
                        TextButton(onClick = {
                            ctx.launchSafely(Permissions.allFilesIntent(ctx), Permissions.allFilesFallbackIntent())
                        }) { Text("Conceder") }
                    }
                }
                ShizukuCard(vm)
                SmallNote("Sin conexión a Internet: la app no tiene permiso INTERNET y no envía ningún dato.")
            }
        },
    )
}
