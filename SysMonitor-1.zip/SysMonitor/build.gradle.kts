// Versiones probadas juntas: AGP 8.7.3 + Gradle 8.9 + Kotlin 2.0.21 + Compose BOM 2024.12.01
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}
